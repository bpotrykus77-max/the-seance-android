package com.seance.core

sealed interface HostDirective {
    data class ForceReply(val text: String) : HostDirective
    data class InjectFact(val key: String, val value: String) : HostDirective
    data class SetIntensity(val value: Int) : HostDirective
    data object ForceClimax : HostDirective
    data object ForceClosing : HostDirective
}
