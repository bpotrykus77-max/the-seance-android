package com.seance.core

class SessionDirector(
    initialProfile: SpiritProfile,
    private val safety: SafetyFilter = ConservativeSafetyFilter()
) {
    var state = SessionState(memory = SessionMemory(initialProfile))
        private set

    fun begin() { require(state.phase == SessionPhase.IDLE); state = state.copy(phase = SessionPhase.INVOCATION) }
    fun establishContact() { require(state.phase == SessionPhase.INVOCATION); state = state.copy(phase = SessionPhase.CONTACT, contactEstablished = true) }
    fun enterDialogue() { require(state.phase == SessionPhase.CONTACT); state = state.copy(phase = SessionPhase.DIALOGUE) }

    fun participantSays(id: String, text: String) {
        require(state.phase in setOf(SessionPhase.DIALOGUE, SessionPhase.ESCALATION, SessionPhase.CLIMAX))
        append(TranscriptItem(id, Role.PARTICIPANT, text.trim().take(500), Source.USER))
    }

    fun spiritReplies(id: String, raw: String, source: Source = Source.AI): SpiritResponse {
        require(state.phase in setOf(SessionPhase.DIALOGUE, SessionPhase.ESCALATION, SessionPhase.CLIMAX, SessionPhase.CLOSING))
        val safe = safety.sanitize(raw)
        val response = SpiritResponse(id, safe.text, source)
        append(TranscriptItem(id, Role.SPIRIT, response.text, source))
        return response
    }

    fun applyHostDirective(id: String, directive: HostDirective): SpiritResponse? {
        return when (directive) {
            is HostDirective.ForceReply -> spiritReplies(id, directive.text, Source.HOST_OVERRIDE)
            is HostDirective.InjectFact -> {
                val f = MemoryFact(directive.key, directive.value)
                state = state.copy(memory = state.memory.copy(facts = state.memory.facts + (directive.key to f)))
                null
            }
            is HostDirective.SetIntensity -> {
                state = state.copy(memory = state.memory.copy(intensity = directive.value.coerceIn(0, 100)))
                null
            }
            HostDirective.ForceClimax -> { state = state.copy(phase = SessionPhase.CLIMAX); null }
            HostDirective.ForceClosing -> { state = state.copy(phase = SessionPhase.CLOSING); null }
        }
    }

    fun escalate() { require(state.phase == SessionPhase.DIALOGUE); state = state.copy(phase = SessionPhase.ESCALATION) }
    fun climax() { require(state.phase in setOf(SessionPhase.DIALOGUE, SessionPhase.ESCALATION)); state = state.copy(phase = SessionPhase.CLIMAX) }
    fun close() { require(state.phase != SessionPhase.ENDED); state = state.copy(phase = SessionPhase.CLOSING) }
    fun end() { require(state.phase == SessionPhase.CLOSING); state = state.copy(phase = SessionPhase.ENDED, closedCleanly = true) }

    private fun append(item: TranscriptItem) {
        state = state.copy(memory = state.memory.copy(transcript = state.memory.transcript + item))
    }
}
