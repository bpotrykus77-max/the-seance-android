package com.seance.core

data class PlanchetteToken(val symbol: String, val dwellMs: Long, val haptic: HapticCue)
enum class HapticCue { NONE, TICK, CONFIRM, EVENT }

class PlanchetteSequencer {
    fun sequence(text: String): List<PlanchetteToken> {
        val cleaned = text.uppercase().filter { it.isLetterOrDigit() || it == ' ' || it == '?' }
        return cleaned.map { c ->
            when (c) {
                ' ' -> PlanchetteToken(" ", 180, HapticCue.NONE)
                else -> PlanchetteToken(c.toString(), 360, HapticCue.TICK)
            }
        }
    }
}
