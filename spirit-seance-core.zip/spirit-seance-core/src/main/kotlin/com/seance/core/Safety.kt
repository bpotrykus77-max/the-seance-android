package com.seance.core

interface SafetyFilter {
    fun sanitize(input: String): SafetyResult
}

data class SafetyResult(val allowed: Boolean, val text: String)

class ConservativeSafetyFilter : SafetyFilter {
    private val blocked = listOf(
        Regex("(?i)kill yourself"),
        Regex("(?i)harm yourself"),
        Regex("(?i)suicide instruction")
    )

    override fun sanitize(input: String): SafetyResult {
        val normalized = input.trim().take(240)
        if (normalized.isBlank()) return SafetyResult(false, "...")
        return if (blocked.any { it.containsMatchIn(normalized) }) {
            SafetyResult(false, "NO")
        } else SafetyResult(true, normalized)
    }
}
