package com.seance.core

class FallbackResponder {
    private val neutral = listOf("...", "YES", "NO", "ASK AGAIN", "I AM HERE")
    fun response(seed: Int, phase: SessionPhase): String = when (phase) {
        SessionPhase.CLIMAX -> listOf("LEAVE", "ENOUGH", "GOODBYE")[kotlin.math.abs(seed) % 3]
        SessionPhase.CLOSING -> "GOODBYE"
        else -> neutral[kotlin.math.abs(seed) % neutral.size]
    }
}
