package com.seance.core

enum class SessionPhase { IDLE, INVOCATION, CONTACT, DIALOGUE, ESCALATION, CLIMAX, CLOSING, ENDED }
