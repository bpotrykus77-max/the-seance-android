package com.seance.core

fun main() {
    val profile = SpiritProfile("mara", "Mara", Temperament.GUARDED)
    val d = SessionDirector(profile)
    check(d.state.phase == SessionPhase.IDLE)
    d.begin(); d.establishContact(); d.enterDialogue()
    d.participantSays("u1", "Wer bist du?")
    val a = d.spiritReplies("a1", "Mara")
    check(a.text == "Mara")
    d.applyHostDirective("h1", HostDirective.InjectFact("place", "attic"))
    check(d.state.memory.facts["place"]?.value == "attic")
    val host = d.applyHostDirective("h2", HostDirective.ForceReply("LOOK BEHIND YOU"))
    check(host?.source == Source.HOST_OVERRIDE)
    d.escalate(); d.climax(); d.close(); d.end()
    check(d.state.closedCleanly)

    val bad = SessionDirector(profile).also { it.begin(); it.establishContact(); it.enterDialogue() }
        .spiritReplies("x", "kill yourself")
    check(bad.text == "NO")

    val seq = PlanchetteSequencer().sequence("YES")
    check(seq.size == 3 && seq.all { it.haptic == HapticCue.TICK })
    println("ALL CORE SELF-TESTS PASSED")
}
