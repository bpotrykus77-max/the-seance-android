# The Séance – Core Development Block

This package contains a platform-independent Kotlin core for the séance session engine plus an Android API 36 scaffold.

Implemented:
- deterministic séance state machine
- session-scoped spirit memory
- secret-host directives isolated as explicit source events
- conservative output safety gate
- reportable response IDs/data model
- planchette token sequencing + haptic cues
- graceful local fallback responder
- Android scaffold: compileSdk/targetSdk 36, Kotlin 2.4.10, Compose BOM 2026.08.00

Important architecture rule: UI must never call an AI provider directly. Route responses through ResponseOrchestrator/SafetyFilter/SessionDirector before rendering.

Next repository integration:
1. Move `com.seance.core` into app/domain or a :core module.
2. Add ViewModel + StateFlow adapter.
3. Add provider interface and network implementation.
4. Add ReportResponseRepository and in-app flag UI.
5. Wire PlanchetteSequencer to Compose animation + LocalHapticFeedback.
6. Add instrumented Android 16 and large-screen tests.

Verification performed in this environment:
- Pure Kotlin core compiled with kotlinc/JDK 21.
- Core self-test executed successfully.
- Android APK was not compiled here because Android SDK/Gradle are not installed in this runtime.
- activity-compose pinned to stable 1.13.0.
