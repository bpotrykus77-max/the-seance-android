# THE SÉANCE v0.18 — Android build compile fix

Observed in GitHub Actions build #5 during `:app:lintDebug` / `:app:compileDebugKotlin`:

- inaccessible `androidx.compose.foundation.layout.weight` resolution
- unresolved `sp` references in `MainActivity.kt`

Corrections applied:

- removed the direct `layout.weight` import and eliminated the two `Modifier.weight(...)` usages
- intensity meter now uses a responsive `BoxWithConstraints` segment width
- the single Secret Host climax button uses `fillMaxWidth()` instead of weight
- imported `androidx.compose.ui.unit.sp` and converted letter spacing to idiomatic `1.5.sp`, `1.6.sp`, `1.1.sp`
- embedded GitHub Actions workflow updated with the successful ZIP preflight fix and current checkout/setup-java actions

Validation in the local tool environment:

- pure Kotlin core recompiled with `kotlinc`
- `CoreSelfTestV18` passed: `ALL CORE V18 SELF-TESTS PASSED`
- static check confirms no remaining `layout.weight`, `Modifier.weight(...)`, or `androidx.compose.ui.unit.sp(...)` misuse in `MainActivity.kt`

Full Android compilation still requires the GitHub Actions Android environment and is not claimed as passed until CI succeeds.
