import com.seance.core.*

private fun checkThat(value: Boolean, message: String) {
    if (!value) error(message)
}

fun main() {
    val profile = SpiritProfile("mara", "Mara", Temperament.GUARDED)

    val policy = SessionInputPolicy(maxChars = 20)
    val normal = policy.evaluate("   Is   anyone here?   ")
    checkThat(normal.accepted && normal.normalized == "Is anyone here?", "input normalization failed")
    checkThat(!policy.evaluate("     ").accepted, "blank input must be rejected")
    checkThat(!policy.evaluate("aaaaaaaaaaaaaaa").accepted, "repeated-character spam must be rejected")

    val primary = SpiritReplyProvider { ProviderResult.Success("YES") }
    val directorAi = SessionDirector(profile)
    directorAi.begin(); directorAi.establishContact(); directorAi.enterDialogue()
    val aiCoordinator = SessionReplyCoordinator(ReplyOrchestrator(primary))
    val ai = aiCoordinator.submit(directorAi, "p1", "r1", "Are you here?", allowMemoryCallback = false)
    checkThat(ai?.source == Source.AI && ai.text.isNotBlank(), "AI coordinator path failed")
    checkThat(directorAi.state.memory.transcript.any { it.role == Role.PARTICIPANT }, "participant turn missing")
    checkThat(directorAi.state.memory.transcript.any { it.role == Role.SPIRIT }, "spirit turn missing")

    val failing = SpiritReplyProvider { ProviderResult.Failure("offline") }
    val directorFallback = SessionDirector(profile)
    directorFallback.begin(); directorFallback.establishContact(); directorFallback.enterDialogue()
    val fallbackCoordinator = SessionReplyCoordinator(ReplyOrchestrator(failing))
    val fallback = fallbackCoordinator.submit(directorFallback, "p2", "r2", "Can you hear me?", allowMemoryCallback = false)
    checkThat(fallback?.source == Source.LOCAL_FALLBACK, "fallback path failed")

    val hostDirector = SessionDirector(profile)
    hostDirector.begin(); hostDirector.establishContact(); hostDirector.enterDialogue()
    hostDirector.applyHostDirective("fact", HostDirective.InjectFact("host_fact", "red door"))
    val request = ReplyRequest(
        question = "test@example.com 0171 1234567",
        profile = profile,
        phase = hostDirector.state.phase,
        recentTranscript = hostDirector.state.memory.transcript
    )
    val safe = PromptPrivacyPolicy().externalContext(request.recentTranscript)
    checkThat(safe.none { it.source == Source.HOST_OVERRIDE }, "host override leaked into external context")
    val redacted = PromptPrivacyPolicy().redact(request.question)
    checkThat(!redacted.contains("test@example.com") && !redacted.contains("0171 1234567"), "PII redaction failed")

    val snapshot = directorFallback.snapshot()
    val restored = SessionDirector(profile)
    restored.restore(snapshot)
    checkThat(restored.state.phase == directorFallback.state.phase, "snapshot phase restore failed")
    checkThat(restored.state.memory.transcript.size == directorFallback.state.memory.transcript.size, "snapshot transcript restore failed")

    val geometry = BoardGeometry()
    listOf("A", "M", "Z", "1", "0", "YES", "NO", "GOODBYE").forEach {
        val p = geometry.positionFor(it)
        checkThat(p.x in 0f..1f && p.y in 0f..1f, "board geometry out of range for $it")
    }

    val resolver = EntitlementResolver()
    checkThat(resolver.tier(BillingSnapshot()) == AppTier.FREE, "default tier must be free")
    checkThat(StoreProduct.entries.size == 1 && StoreProduct.entries.single() == StoreProduct.PRO_LIFETIME, "only lifetime product may exist")
    val pending = BillingSnapshot(listOf(PurchaseEntitlement(StoreProduct.PRO_LIFETIME, PurchaseState.PENDING, acknowledged = false)))
    checkThat(resolver.tier(pending) == AppTier.FREE, "pending purchase must not unlock pro")
    val unacked = BillingSnapshot(listOf(PurchaseEntitlement(StoreProduct.PRO_LIFETIME, PurchaseState.ACTIVE, acknowledged = false)))
    checkThat(resolver.tier(unacked) == AppTier.FREE && resolver.needsAcknowledgement(unacked), "unacknowledged purchase must remain free")
    val pro = BillingSnapshot(listOf(PurchaseEntitlement(StoreProduct.PRO_LIFETIME, PurchaseState.ACTIVE, acknowledged = true)))
    checkThat(resolver.tier(pro) == AppTier.PRO, "acknowledged lifetime purchase must unlock pro")


    val reducer = PurchaseFlowReducer()
    val staleActive = PurchaseEntitlement(StoreProduct.PRO_LIFETIME, PurchaseState.ACTIVE, acknowledged = true, updatedAtEpochMs = 10)
    val newerRevoked = PurchaseEntitlement(StoreProduct.PRO_LIFETIME, PurchaseState.REVOKED, acknowledged = true, updatedAtEpochMs = 20)
    val revokedSnapshot = BillingSnapshot(listOf(staleActive, newerRevoked))
    checkThat(resolver.tier(revokedSnapshot) == AppTier.FREE, "newer revoked purchase must override stale active purchase")
    checkThat(reducer.from(revokedSnapshot).tier == AppTier.FREE, "purchase reducer revoked handling failed")
    val newerActive = PurchaseEntitlement(StoreProduct.PRO_LIFETIME, PurchaseState.ACTIVE, acknowledged = true, updatedAtEpochMs = 30)
    checkThat(resolver.tier(BillingSnapshot(listOf(newerRevoked, newerActive))) == AppTier.PRO, "newest active purchase must restore pro")
    checkThat(reducer.from(BillingSnapshot(storeReachable = false)).uiState == PurchaseUiState.ERROR, "unreachable store state failed")

    checkThat(SessionHealthMonitor.inspect(directorFallback.state).healthy, "valid session health failed")
    val unhealthy = directorFallback.state.copy(memory = directorFallback.state.memory.copy(intensity = 101))
    checkThat(!SessionHealthMonitor.inspect(unhealthy).healthy, "invalid session health must be detected")

    val noisyLedger = listOf(
        PurchaseEntitlement(StoreProduct.PRO_LIFETIME, PurchaseState.ACTIVE, acknowledged = true, updatedAtEpochMs = 10),
        PurchaseEntitlement(StoreProduct.PRO_LIFETIME, PurchaseState.REVOKED, acknowledged = true, updatedAtEpochMs = 20),
        PurchaseEntitlement(StoreProduct.PRO_LIFETIME, PurchaseState.ACTIVE, acknowledged = true, updatedAtEpochMs = 15)
    )
    val canonical = PurchaseLedgerPolicy.canonical(noisyLedger)
    checkThat(canonical.size == 1 && canonical.single().state == PurchaseState.REVOKED, "purchase ledger canonicalization failed")

    val healthySnapshot = directorFallback.snapshot()
    checkThat(SessionRecoveryPolicy.decide(healthySnapshot).action == RecoveryAction.RESTORE, "healthy snapshot should restore")
    val recoverableSnapshot = healthySnapshot.copy(state = healthySnapshot.state.copy(memory = healthySnapshot.state.memory.copy(intensity = 120)))
    checkThat(SessionRecoveryPolicy.decide(recoverableSnapshot).action == RecoveryAction.SANITIZE_AND_RESTORE, "recoverable snapshot should sanitize")
    checkThat(SessionRecoveryPolicy.recover(recoverableSnapshot)?.state?.memory?.intensity == 100, "snapshot sanitation failed")
    val mismatched = healthySnapshot.copy(state = healthySnapshot.state.copy(contactEstablished = true, phase = SessionPhase.IDLE))
    checkThat(SessionRecoveryPolicy.decide(mismatched).action == RecoveryAction.DISCARD, "phase mismatch should discard")

    val policyV15 = SessionInputPolicy(maxChars = 180, maxRepeatedCharRun = 10, maxWords = 5)
    checkThat(policyV15.evaluate("  hello\u0000   spirit  ").normalized == "hello spirit", "control-char normalization failed")
    checkThat(!policyV15.evaluate("one two three four five six").accepted, "word limit failed")

    val gate = HostAccessGate(requiredTaps = 5, windowMs = 2_500)
    repeat(4) { index -> checkThat(!gate.registerTap(index * 300L, AppTier.PRO), "host gate opened too early") }
    checkThat(gate.registerTap(1_200L, AppTier.PRO), "host gate did not open after valid PRO gesture")
    repeat(5) { index -> checkThat(!gate.registerTap(index * 200L, AppTier.FREE), "FREE must never open Secret Host") }
    checkThat(!gate.registerTap(0L, AppTier.PRO) && !gate.registerTap(3_000L, AppTier.PRO), "expired host gesture window must reset")

    val restorePolicy = PurchaseRestorePolicy()
    checkThat(restorePolicy.evaluate(pro).disposition == RestoreDisposition.PRO_RESTORED, "PRO purchase restore failed")
    checkThat(restorePolicy.evaluate(BillingSnapshot()).disposition == RestoreDisposition.FREE_CONFIRMED, "FREE restore state failed")
    checkThat(restorePolicy.evaluate(BillingSnapshot(storeReachable = false)).disposition == RestoreDisposition.RETRY_REQUIRED, "offline restore must request retry")

    
    val hostPolicy = HostDirectivePolicy(cooldownMs = 1_000)
    val hostFirst = hostPolicy.validateReply("  COME\u0000   CLOSER  ", 1_000)
    checkThat(hostFirst.accepted && hostFirst.normalizedText == "COME CLOSER", "host directive sanitation failed")
    checkThat(!hostPolicy.validateReply("SECOND", 1_500).accepted, "host directive cooldown failed")
    checkThat(hostPolicy.validateFact("  red   door  ", 2_100).accepted, "host fact should pass after cooldown")

    val breaker = ReplyCircuitBreaker(failureThreshold = 2, openDurationMs = 5_000)
    checkThat(breaker.allowRequest(1_000), "closed circuit should allow request")
    breaker.recordFailure(1_000)
    checkThat(breaker.allowRequest(1_100), "circuit should still allow before threshold")
    breaker.recordFailure(1_100)
    checkThat(breaker.snapshot(1_200).state == CircuitState.OPEN, "circuit should open after threshold")
    checkThat(!breaker.allowRequest(2_000), "open circuit must block request")
    checkThat(breaker.allowRequest(6_200), "half-open circuit should allow one probe")
    checkThat(!breaker.allowRequest(6_300), "half-open circuit must allow only one probe")
    breaker.recordSuccess()
    checkThat(breaker.snapshot(6_400).state == CircuitState.CLOSED, "successful probe should close circuit")


    var providerCalls = 0
    var now = 10_000L
    val unstableProvider = SpiritReplyProvider {
        providerCalls++
        ProviderResult.Failure("offline")
    }
    val guardedProvider = CircuitBreakingReplyProvider(
        delegate = unstableProvider,
        breaker = ReplyCircuitBreaker(failureThreshold = 1, openDurationMs = 5_000),
        clockMs = { now }
    )
    guardedProvider.generate(ReplyRequest("q", profile, SessionPhase.DIALOGUE, emptyList()))
    now += 100
    val blocked = guardedProvider.generate(ReplyRequest("q2", profile, SessionPhase.DIALOGUE, emptyList()))
    checkThat(blocked is ProviderResult.Failure && providerCalls == 1, "circuit provider must avoid repeated remote calls")


    // v18: Polish name memory must be recognized without language mixing.
    val memoryEngineV18 = MemoryEngine()
    val baseMemory = SessionMemory(profile)
    val polishMemory = memoryEngineV18.observeParticipant(baseMemory, "Mam na imię Zofia")
    checkThat(polishMemory.facts["participant_name"]?.value == "Zofia", "Polish participant-name memory failed")

    // v18: host facts are deliberately delayed and should surface only on a natural trigger or after overdue time.
    var delayedMemory = memoryEngineV18.injectFact(baseMemory, "host_fact", "MAX")
    checkThat(delayedMemory.cues.single().eligibleAfterTurn == 3, "host fact must use delayed callback window")
    repeat(2) { delayedMemory = memoryEngineV18.observeParticipant(delayedMemory, "ordinary question") }
    checkThat(memoryEngineV18.nextCallback(delayedMemory, "ordinary question") == null, "host fact surfaced too early")
    delayedMemory = memoryEngineV18.observeParticipant(delayedMemory, "What was the name?")
    val naturalCallback = memoryEngineV18.nextCallback(delayedMemory, "What was the name?")
    checkThat(naturalCallback?.second == "MAX...", "natural delayed host callback failed")

    // v18: signature board uses three distinct letter bands and lower YES/NO threshold positions.
    val a = geometry.positionFor("A")
    val j = geometry.positionFor("J")
    val sPoint = geometry.positionFor("S")
    checkThat(a.y < j.y && j.y < sPoint.y, "signature letter bands are not vertically distinct")
    checkThat(geometry.positionFor("YES").y > sPoint.y && geometry.positionFor("NO").y > sPoint.y, "YES/NO must sit below letter arena")

    println("ALL CORE V18 SELF-TESTS PASSED")
}
