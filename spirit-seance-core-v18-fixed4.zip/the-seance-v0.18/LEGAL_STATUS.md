# Legal status
Vorbereitet: DE/PL/EN Rechtstexte, KI-/Entertainment-Hinweise, PRO-Kauftext, Reportingprozess, Marketingregeln und Store-Checkliste.

Nicht automatisch abschließbar ohne echte Betreiber-/Store-/Providerdaten: Anbieteranschrift, E-Mail, Register/Steuernummern, KI-/Hostinganbieter, Löschfristen, Drittlandtransfer, Store-Produkt-ID/Preis, Altersfreigabe und Store-Erklärungen. Diese Platzhalter müssen vor Release wahrheitsgemäß ersetzt werden.
