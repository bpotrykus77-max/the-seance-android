# The Séance v0.17

Pre-release Android package for the Spirit Board / The Séance project.

## v0.17 visual production block
- clearer live-session visual hierarchy with localized “Séance active” chip
- spirit-message plaque separated from the board typography
- animated planchette scale emphasis in addition to spatial movement
- localized board guidance for DE / PL / EN
- Secret Host safety note integrated into the hidden panel

## v0.17 technical production block
- `HostDirectivePolicy`: sanitizes and rate-limits hidden Host text/facts
- `ReplyCircuitBreaker`: protects a future remote AI provider from repeated failure storms
- `CircuitBreakingReplyProvider`: store-/transport-neutral provider wrapper
- Android network hardening: HTTPS-only app policy (`usesCleartextTraffic=false`)
- Android backup disabled so active local séance/host state is not copied by platform backup
- INTERNET permission prepared for production HTTPS AI backend
- CI now runs Android lint before APK assembly
- version `0.17.0`, versionCode `17`

## Verification performed locally
- pure Kotlin core compiled with `kotlinc`
- `CoreSelfTestV17`: passed
- DE/PL/EN string-key parity checked
- Android XML parsed
- `R.string` references checked
- GitHub Actions YAML parsed
- ZIP integrity checked

## Still requires real Android/Store validation
A production claim still depends on a real Android APK/AAB build, device testing, Play Billing, production AI backend, signing, audio assets/tuning and store review QA.


## v0.18 design/differentiation block
- Signature three-band board geometry and asymmetric threshold layout.
- Living-board violet response accent driven by phase/intensity.
- Delayed/natural memory callbacks for host facts instead of immediate reveal.
- Polish participant-name memory patterns.
