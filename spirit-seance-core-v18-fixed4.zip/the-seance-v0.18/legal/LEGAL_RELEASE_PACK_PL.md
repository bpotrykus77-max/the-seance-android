# THE SÉANCE – Pakiet prawny (PL)
Stan 26.08.2026

Administrator/dostawca: [PEŁNA NAZWA/FIRMA], [ADRES], [E-MAIL].

THE SÉANCE jest aplikacją rozrywkową. Stan sesji, pytania, odpowiedzi, pamięć sesji i dane Secret Host są – o ile to technicznie możliwe – przetwarzane lokalnie. Przy użyciu AI online oczyszczone pytanie i ograniczony niezbędny kontekst mogą zostać przekazane do [DOSTAWCA AI]. Zbędne dane są minimalizowane, a typowe dane kontaktowe redagowane w miarę możliwości. Dane Secret Host nie są rutynowo przekazywane zewnętrznym usługom AI. Odbiorcy: [AI], [HOSTING]. Transfer poza EOG: [TAK/NIE + PODSTAWA]. Okres przechowywania: [OKRES].

PRO Lifetime jest jednorazowym zakupem w aplikacji obsługiwanym przez sklep. Aplikacja przetwarza tylko informacje potrzebne do potwierdzenia i przywrócenia uprawnienia. Problematyczną odpowiedź AI można zgłosić bez opuszczania aplikacji.

**Rozrywka i AI** – THE SÉANCE jest fikcyjnym doświadczeniem rozrywkowym. Odpowiedzi mogą być generowane automatycznie lub przez AI. Aplikacja nie zapewnia rzeczywistego kontaktu ze zmarłymi ani istotami paranormalnymi.

Secret Host jest ukrytą mechaniką gry wyłącznie do celów rozrywkowych i nie może być używany do krzywdzenia, zastraszania, szantażu ani nadużyciowej manipulacji. Ustawowe prawa konsumenta pozostają bez zmian.
