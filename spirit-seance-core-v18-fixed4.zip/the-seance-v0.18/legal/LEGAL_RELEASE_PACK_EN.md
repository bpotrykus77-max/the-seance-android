# THE SÉANCE – Legal Pack (EN)
Effective 26 August 2026

Provider/controller: [FULL LEGAL NAME/COMPANY], [ADDRESS], [EMAIL].

THE SÉANCE is an entertainment app. Session state, questions, answers, session memory and Secret Host information are intended to be processed locally where technically possible. When online AI is used, a sanitized question and limited necessary context may be sent to [AI PROVIDER]. Unnecessary data is minimized and common contact details are redacted where possible. Secret Host information is not routinely sent externally. Recipients: [AI PROVIDER], [HOSTING]. International transfers: [YES/NO + MECHANISM]. Retention: [PERIOD].

PRO Lifetime is a one-time in-app purchase handled by the relevant app store. The app processes only entitlement information needed to unlock, verify and restore access. Problematic AI output can be reported without leaving the app.

**Entertainment & AI** – THE SÉANCE is a fictional entertainment experience. Responses may be generated automatically or by AI. The app does not provide real contact with deceased persons or paranormal entities.

Secret Host is a hidden game mechanic for entertainment only and must not be used for harm, intimidation, blackmail or abusive manipulation. Statutory consumer rights remain unaffected.
