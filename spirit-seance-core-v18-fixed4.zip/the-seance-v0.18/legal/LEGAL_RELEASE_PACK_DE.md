# THE SÉANCE – Rechtspaket (DE)
Stand 26.08.2026

## Anbieterkennzeichnung (§ 5 DDG)
Anbieter: [VOLLSTÄNDIGER NAME/FIRMA]
Rechtsform: [FALLS ZUTREFFEND]
Anschrift: [LADUNGSFÄHIGE ANSCHRIFT]
E-Mail: [KONTAKT-E-MAIL]
Register/Registernummer: [FALLS VORHANDEN]
USt-IdNr./W-IdNr.: [FALLS VORHANDEN]

## Datenschutzerklärung – Kerntext
THE SÉANCE ist eine Entertainment-App. Sitzungszustand, Fragen, Antworten, Memory-Informationen und Secret-Host-Eingaben sollen soweit technisch möglich lokal verarbeitet werden. Wird eine Online-KI-Antwort verwendet, können ein bereinigter Fragetext und begrenzter erforderlicher Kontext an [KI-PROVIDER] übertragen werden. Unnötige Daten werden minimiert; typische Kontaktangaben werden nach Möglichkeit redigiert. Secret-Host-Daten werden nicht routinemäßig extern übertragen. Rechtsgrundlage ist Art. 6 Abs. 1 lit. b DSGVO, soweit die Verarbeitung zur angeforderten Funktion erforderlich ist; sonst nur eine jeweils einschlägige Rechtsgrundlage. Empfänger: [KI-PROVIDER], [HOSTING/BACKEND]. Drittlandtransfer: [JA/NEIN + MECHANISMUS]. Speicherdauer: [FRIST].

PRO Lifetime wird über den jeweiligen App-Store abgewickelt. Zahlungsdaten werden grundsätzlich vom Store verarbeitet; die App verarbeitet nur für Freischaltung, Prüfung und Wiederherstellung erforderliche Entitlement-Informationen. Problematische KI-Ausgaben können direkt in der App gemeldet werden; Antwort-ID, Meldegrund und gemeldeter Inhalt werden dafür maximal [FRIST] verarbeitet. Externe Kommunikation soll ausschließlich HTTPS verwenden; sensible Session-/Host-Daten sollen nicht unnötig in Cloud-Backups gelangen. Betroffenenrechte nach DSGVO bleiben unberührt.

## Nutzungsbedingungen – Kerntext
THE SÉANCE ist ein fiktionales Entertainment-/Party-Erlebnis und behauptet nicht, tatsächlich mit Verstorbenen, Geistern oder paranormalen Wesen zu kommunizieren. Antworten können automatisiert und/oder durch generative KI erzeugt werden und sind keine Tatsachenfeststellungen, Beratung, Vorhersagen oder paranormalen Nachweise. Secret Host ist eine verdeckte Spielmechanik zur Unterhaltung und darf nicht für Schädigung, Einschüchterung, Erpressung oder missbräuchliche Manipulation eingesetzt werden. PRO Lifetime ist ein einmaliger In-App-Kauf; maßgeblich sind die in der Store-/Kaufansicht beschriebenen Funktionen und der dort angezeigte Preis. Wiederherstellbare Käufe müssen wiederherstellbar sein. Gesetzliche Verbraucher- und Mängelrechte bleiben unberührt.

## Pflichttext vor erster Séance
**Entertainment & KI** – THE SÉANCE ist ein fiktionales Entertainment-Erlebnis. Antworten können automatisiert oder durch KI erzeugt werden. Die App stellt keinen echten Kontakt zu Verstorbenen oder paranormalen Wesen her.

## PRO-Kauftext
**PRO Lifetime – einmal kaufen, dauerhaft freischalten. Kein Abonnement.** Maßgeblich ist der vom Store angezeigte Preis. Online-KI-Funktionen können Internet und externe Dienste benötigen.
