# THE SÉANCE – Store/Legal Release Checklist

## Google Play
- [ ] Privacy Policy URL live
- [ ] Data Safety anhand realer SDKs/Provider
- [ ] In-App-Meldung für KI-Ausgaben getestet
- [ ] Inhaltsfilter getestet
- [ ] PRO Lifetime als One-Time Product über Play Billing
- [ ] Pending/Refund/Revocation/Restore getestet
- [ ] tatsächlichen Store-Preis anzeigen
- [ ] Content Rating und Target Audience
- [ ] AI-Asset-Selbsterklärung, falls erforderlich
- [ ] keine irreführenden Paranormalitäts-Claims

## Apple
- [ ] Privacy Policy URL / App Privacy
- [ ] PRO Lifetime als Non-Consumable IAP
- [ ] Restore Purchases getestet
- [ ] IAP für Review sichtbar/funktional
- [ ] Review Notes erklären Secret Host, KI und IAP
- [ ] Age Rating
- [ ] On-device Stabilität
- [ ] PRO-Käufe in Metadaten klar

## Betreiber/EU
- [ ] §5-DDG-Angaben vollständig
- [ ] reale Provider/Fristen/Drittlandtransfers in Datenschutztexten
- [ ] KI-Transparenz vor erster KI-Interaktion
- [ ] Verbraucherinformationen vor Kauf
- [ ] Supportkontakt
- [ ] Update-/Sicherheitsprozess
