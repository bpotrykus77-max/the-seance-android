# KI-Meldung und Marketing

## KI-Meldung
Jede reportable KI-Antwort erhält eine Response-ID. Direkt in der App: Antwort melden / Zgłoś odpowiedź / Report response. Minimaldaten: Response-ID, Text, Sprache, Meldegrund, Zeitpunkt. Kategorien: Hass/Belästigung, sexualisierte Inhalte, Selbstgefährdung, Gewalt, personenbezogene Daten, Täuschung/Betrug, Sonstiges. Aufbewahrung: [FRIST].

## Marketing – verwenden
- KI-gestützte interaktive Séance
- Mystery-Party-Erlebnis
- Secret Host kann die Inszenierung heimlich beeinflussen
- Für Unterhaltung

## Marketing – nicht verwenden
- Sprich wirklich mit Toten
- Beweist echte Geister
- 100 % echte paranormale Kommunikation
- Die App erkennt echte Geister
- irreführende Preis-, KI- oder Sensor-Claims

Store-Screenshots und Beschreibungen müssen erkennen lassen, wenn gezeigte Funktionen PRO erfordern.
