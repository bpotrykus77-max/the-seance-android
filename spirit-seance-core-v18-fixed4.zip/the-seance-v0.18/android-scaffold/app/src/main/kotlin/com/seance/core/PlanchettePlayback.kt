package com.seance.core

data class PlaybackFrame(
    val symbol: String,
    val delayMs: Long,
    val haptic: HapticCue
)

class PlanchettePlayback(private val sequencer: PlanchetteSequencer = PlanchetteSequencer()) {
    fun frames(response: SpiritResponse?): List<PlaybackFrame> {
        if (response == null || response.text.isBlank()) return emptyList()
        return sequencer.sequence(response.text).map {
            PlaybackFrame(it.symbol, it.dwellMs.coerceIn(80L, 900L), it.haptic)
        }
    }

    fun estimatedDurationMs(response: SpiritResponse?): Long = frames(response).sumOf { it.delayMs }
}
