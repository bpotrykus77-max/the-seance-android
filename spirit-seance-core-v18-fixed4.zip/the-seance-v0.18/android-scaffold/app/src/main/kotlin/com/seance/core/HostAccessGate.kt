package com.seance.core

/**
 * Guards the hidden Secret Host gesture against accidental activation.
 * Only PRO can complete the gesture, and taps must occur inside a short window.
 */
class HostAccessGate(
    private val requiredTaps: Int = 5,
    private val windowMs: Long = 2_500L
) {
    init {
        require(requiredTaps >= 2)
        require(windowMs > 0)
    }

    private var tapCount = 0
    private var firstTapAt = -1L

    fun registerTap(nowMs: Long, tier: AppTier): Boolean {
        if (tier != AppTier.PRO) {
            reset()
            return false
        }
        if (firstTapAt < 0L || nowMs - firstTapAt > windowMs || nowMs < firstTapAt) {
            tapCount = 0
            firstTapAt = nowMs
        }
        tapCount += 1
        if (tapCount >= requiredTaps) {
            reset()
            return true
        }
        return false
    }

    fun reset() {
        tapCount = 0
        firstTapAt = -1L
    }
}
