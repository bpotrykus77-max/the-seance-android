package com.seance.core

/** Transport seam for a future HTTPS backend. API keys intentionally do not belong in the app. */
fun interface ReplyTransport {
    fun post(endpoint: String, payload: RemoteReplyPayload): TransportReply
}

data class RemoteReplyPayload(
    val question: String,
    val spiritId: String,
    val phase: String,
    val context: List<String>
)

data class TransportReply(val code: Int, val body: String)

class RemoteEndpointPolicy {
    fun validate(endpoint: String): Boolean {
        val normalized = endpoint.trim()
        return normalized.startsWith("https://") &&
            !normalized.contains("localhost", ignoreCase = true) &&
            !normalized.contains("127.0.0.1") &&
            normalized.length <= 300
    }
}

class RemoteSpiritReplyProvider(
    private val endpoint: String,
    private val transport: ReplyTransport,
    private val privacy: PromptPrivacyPolicy = PromptPrivacyPolicy(),
    private val endpointPolicy: RemoteEndpointPolicy = RemoteEndpointPolicy()
) : SpiritReplyProvider {
    override fun generate(request: ReplyRequest): ProviderResult {
        if (!endpointPolicy.validate(endpoint)) return ProviderResult.Failure("invalid_endpoint")

        val safeContext = privacy.externalContext(request.recentTranscript)
        val payload = RemoteReplyPayload(
            question = privacy.redact(request.question).take(500),
            spiritId = request.profile.id.take(80),
            phase = request.phase.name,
            context = safeContext.takeLast(8).map { it.text }
        )

        val reply = try { transport.post(endpoint, payload) } catch (_: Throwable) {
            return ProviderResult.Failure("transport_exception")
        }
        if (reply.code !in 200..299) return ProviderResult.Failure("http_${reply.code}")
        val text = reply.body.trim().take(800)
        return if (text.isBlank()) ProviderResult.Failure("empty_reply") else ProviderResult.Success(text)
    }
}
