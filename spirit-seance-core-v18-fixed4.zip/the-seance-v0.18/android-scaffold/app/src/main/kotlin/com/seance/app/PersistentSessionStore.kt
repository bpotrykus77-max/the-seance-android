package com.seance.app

import android.content.Context
import com.seance.core.SessionSnapshot
import com.seance.core.SessionSnapshotCodec
import com.seance.core.SessionRecoveryPolicy

class PersistentSessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("seance_session", Context.MODE_PRIVATE)

    fun save(snapshot: SessionSnapshot) {
        prefs.edit().putString(KEY, SessionSnapshotCodec.encode(snapshot)).apply()
    }

    fun load(): SessionSnapshot? = prefs.getString(KEY, null)
        ?.let(SessionSnapshotCodec::decode)
        ?.let(SessionRecoveryPolicy::recover)

    fun clear() {
        prefs.edit().remove(KEY).apply()
    }

    private companion object {
        const val KEY = "active_snapshot"
    }
}
