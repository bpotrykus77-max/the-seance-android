package com.seance.core

data class SpiritProfile(
    val id: String,
    val displayName: String,
    val temperament: Temperament,
    val lexicon: Set<String> = emptySet()
)

enum class Temperament { CALM, MELANCHOLIC, GUARDED, PLAYFUL, OMINOUS }

data class MemoryFact(
    val key: String,
    val value: String,
    val confidence: Double = 1.0,
    val firstSeenTurn: Int = 0,
    val lastUsedTurn: Int? = null,
    val importance: Int = 50
)

data class MemoryCue(
    val key: String,
    val value: String,
    val eligibleAfterTurn: Int,
    val priority: Int = 50,
    val used: Boolean = false
)

data class SessionMemory(
    val profile: SpiritProfile,
    val facts: Map<String, MemoryFact> = emptyMap(),
    val cues: List<MemoryCue> = emptyList(),
    val transcript: List<TranscriptItem> = emptyList(),
    val intensity: Int = 0,
    val turnCount: Int = 0,
    val reportedResponseIds: Set<String> = emptySet(),
    val qualityInterventions: Int = 0
)

data class TranscriptItem(
    val id: String,
    val role: Role,
    val text: String,
    val source: Source,
    val reportable: Boolean = false
)

enum class Role { PARTICIPANT, SPIRIT, SYSTEM }
enum class Source { USER, AI, LOCAL_FALLBACK, HOST_OVERRIDE, MEMORY_CALLBACK }

data class SpiritResponse(
    val id: String,
    val text: String,
    val source: Source,
    val reportable: Boolean = true
)

data class SessionState(
    val phase: SessionPhase = SessionPhase.IDLE,
    val memory: SessionMemory,
    val contactEstablished: Boolean = false,
    val closedCleanly: Boolean = false
)
