package com.seance.core

data class SessionSnapshot(
    val schemaVersion: Int = CURRENT_SCHEMA,
    val state: SessionState
) {
    companion object { const val CURRENT_SCHEMA = 1 }
}

object SessionSnapshotPolicy {
    private const val MAX_TRANSCRIPT_ITEMS = 200
    private const val MAX_TEXT_LENGTH = 500
    private const val MAX_FACTS = 64
    private const val MAX_CUES = 64

    fun sanitize(snapshot: SessionSnapshot): SessionSnapshot {
        require(snapshot.schemaVersion == SessionSnapshot.CURRENT_SCHEMA) { "Unsupported snapshot schema" }
        val old = snapshot.state
        val memory = old.memory
        val safeTranscript = memory.transcript.takeLast(MAX_TRANSCRIPT_ITEMS).map {
            it.copy(text = it.text.trim().replace(Regex("\\s+"), " ").take(MAX_TEXT_LENGTH))
        }
        val safeFacts = memory.facts.entries.take(MAX_FACTS).associate { (key, value) ->
            key.take(80) to value.copy(
                key = key.take(80),
                value = value.value.take(MAX_TEXT_LENGTH),
                confidence = value.confidence.coerceIn(0.0, 1.0),
                importance = value.importance.coerceIn(0, 100)
            )
        }
        val safeCues = memory.cues.take(MAX_CUES).map {
            it.copy(
                key = it.key.take(80),
                value = it.value.take(MAX_TEXT_LENGTH),
                eligibleAfterTurn = it.eligibleAfterTurn.coerceAtLeast(0),
                priority = it.priority.coerceIn(0, 100)
            )
        }
        return SessionSnapshot(
            state = old.copy(
                memory = memory.copy(
                    facts = safeFacts,
                    cues = safeCues,
                    transcript = safeTranscript,
                    intensity = memory.intensity.coerceIn(0, 100),
                    turnCount = memory.turnCount.coerceAtLeast(0),
                    qualityInterventions = memory.qualityInterventions.coerceAtLeast(0)
                )
            )
        )
    }
}
