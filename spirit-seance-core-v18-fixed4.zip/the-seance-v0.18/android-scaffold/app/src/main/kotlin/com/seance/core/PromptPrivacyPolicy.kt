package com.seance.core

class PromptPrivacyPolicy(
    private val maxItems: Int = 6,
    private val maxCharsPerItem: Int = 240
) {
    private val email = Regex("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}", RegexOption.IGNORE_CASE)
    private val phone = Regex("(?<!\\d)(?:\\+?\\d[\\d .()/-]{6,}\\d)(?!\\d)")

    fun externalContext(transcript: List<TranscriptItem>): List<TranscriptItem> = transcript
        .asSequence()
        .filter { it.role != Role.SYSTEM }
        .filter { it.source != Source.HOST_OVERRIDE }
        .toList()
        .takeLast(maxItems)
        .map { it.copy(text = redact(it.text).take(maxCharsPerItem)) }

    fun redact(text: String): String = text
        .replace(email, "[EMAIL]")
        .replace(phone, "[PHONE]")
        .trim()
}
