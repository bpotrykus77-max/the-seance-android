package com.seance.core

/**
 * Prevents memory/host facts from firing immediately after they are learned.
 * A callback becomes natural either when the current question semantically invites it,
 * or when the cue has been waiting long enough to avoid never surfacing.
 */
class CallbackPolicy(
    private val overdueTurns: Int = 5
) {
    private val triggerPatterns = listOf(
        Regex("(?i)\\b(who|name|called|remember|know|person|he|she)\\b"),
        Regex("(?i)\\b(wer|name|hei(?:ß|ss)t|erinner|wei(?:ß|ss)t|person)\\b"),
        Regex("(?i)\\b(kto|imi(?:ę|e)|nazywa|pamięta|pamieta|wiesz|osoba)\\b")
    )

    fun shouldSurface(memory: SessionMemory, cue: MemoryCue, question: String): Boolean {
        if (cue.used || memory.turnCount < cue.eligibleAfterTurn) return false
        val normalized = question.trim()
        val semanticallyInvited = triggerPatterns.any { it.containsMatchIn(normalized) }
        val overdue = memory.turnCount - cue.eligibleAfterTurn >= overdueTurns
        return semanticallyInvited || overdue
    }
}
