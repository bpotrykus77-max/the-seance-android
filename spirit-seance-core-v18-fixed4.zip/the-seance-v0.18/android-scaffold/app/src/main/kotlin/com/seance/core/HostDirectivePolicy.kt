package com.seance.core

data class HostDirectiveDecision(
    val accepted: Boolean,
    val normalizedText: String = "",
    val reason: String? = null
)

/**
 * Sanitizes and rate-limits text entered in the hidden host surface.
 * The policy intentionally contains no UI strings so it can be tested on the JVM.
 */
class HostDirectivePolicy(
    private val maxReplyChars: Int = 120,
    private val maxFactChars: Int = 80,
    private val cooldownMs: Long = 900L
) {
    init {
        require(maxReplyChars in 20..500)
        require(maxFactChars in 10..300)
        require(cooldownMs >= 0)
    }

    private var lastAcceptedAtMs: Long = Long.MIN_VALUE

    fun validateReply(raw: String, nowMs: Long): HostDirectiveDecision = validate(raw, maxReplyChars, nowMs)

    fun validateFact(raw: String, nowMs: Long): HostDirectiveDecision = validate(raw, maxFactChars, nowMs)

    private fun validate(raw: String, limit: Int, nowMs: Long): HostDirectiveDecision {
        val normalized = raw
            .filterNot { it.isISOControl() && it != '\n' && it != '\t' }
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(limit)
        if (normalized.isBlank()) return HostDirectiveDecision(false, reason = "blank")
        if (lastAcceptedAtMs != Long.MIN_VALUE && nowMs >= lastAcceptedAtMs && nowMs - lastAcceptedAtMs < cooldownMs) {
            return HostDirectiveDecision(false, normalized, "cooldown")
        }
        if (nowMs < lastAcceptedAtMs) lastAcceptedAtMs = Long.MIN_VALUE
        lastAcceptedAtMs = nowMs
        return HostDirectiveDecision(true, normalized)
    }
}
