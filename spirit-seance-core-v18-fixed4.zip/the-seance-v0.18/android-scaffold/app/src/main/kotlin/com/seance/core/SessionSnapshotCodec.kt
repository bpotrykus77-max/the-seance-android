package com.seance.core

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.util.Base64

/** Compact, dependency-free snapshot codec for local persistence. */
object SessionSnapshotCodec {
    private const val MAGIC = "SEANCE_SNAPSHOT_V1"

    fun encode(snapshot: SessionSnapshot): String {
        val safe = SessionSnapshotPolicy.sanitize(snapshot)
        val buffer = ByteArrayOutputStream()
        DataOutputStream(buffer).use { out ->
            out.writeUTF(MAGIC)
            out.writeInt(safe.schemaVersion)
            val state = safe.state
            out.writeUTF(state.phase.name)
            out.writeBoolean(state.contactEstablished)
            out.writeBoolean(state.closedCleanly)

            val memory = state.memory
            writeProfile(out, memory.profile)
            out.writeInt(memory.intensity)
            out.writeInt(memory.turnCount)
            out.writeInt(memory.qualityInterventions)

            out.writeInt(memory.facts.size)
            memory.facts.values.forEach { fact ->
                out.writeUTF(fact.key)
                out.writeUTF(fact.value)
                out.writeDouble(fact.confidence)
                out.writeInt(fact.firstSeenTurn)
                out.writeBoolean(fact.lastUsedTurn != null)
                if (fact.lastUsedTurn != null) out.writeInt(fact.lastUsedTurn)
                out.writeInt(fact.importance)
            }

            out.writeInt(memory.cues.size)
            memory.cues.forEach { cue ->
                out.writeUTF(cue.key)
                out.writeUTF(cue.value)
                out.writeInt(cue.eligibleAfterTurn)
                out.writeInt(cue.priority)
                out.writeBoolean(cue.used)
            }

            out.writeInt(memory.transcript.size)
            memory.transcript.forEach { item ->
                out.writeUTF(item.id)
                out.writeUTF(item.role.name)
                out.writeUTF(item.text)
                out.writeUTF(item.source.name)
                out.writeBoolean(item.reportable)
            }

            out.writeInt(memory.reportedResponseIds.size)
            memory.reportedResponseIds.forEach(out::writeUTF)
        }
        return Base64.getEncoder().encodeToString(buffer.toByteArray())
    }

    fun decode(encoded: String): SessionSnapshot? = runCatching {
        val bytes = Base64.getDecoder().decode(encoded)
        DataInputStream(ByteArrayInputStream(bytes)).use { input ->
            require(input.readUTF() == MAGIC) { "Invalid snapshot" }
            val schema = input.readInt()
            require(schema == SessionSnapshot.CURRENT_SCHEMA) { "Unsupported snapshot schema" }
            val phase = SessionPhase.valueOf(input.readUTF())
            val contactEstablished = input.readBoolean()
            val closedCleanly = input.readBoolean()
            val profile = readProfile(input)
            val intensity = input.readInt()
            val turnCount = input.readInt()
            val qualityInterventions = input.readInt()

            val facts = buildMap {
                repeat(input.readInt().coerceIn(0, 64)) {
                    val key = input.readUTF()
                    val value = input.readUTF()
                    val confidence = input.readDouble()
                    val firstSeenTurn = input.readInt()
                    val lastUsedTurn = if (input.readBoolean()) input.readInt() else null
                    val importance = input.readInt()
                    put(key, MemoryFact(key, value, confidence, firstSeenTurn, lastUsedTurn, importance))
                }
            }

            val cues = buildList {
                repeat(input.readInt().coerceIn(0, 64)) {
                    add(
                        MemoryCue(
                            key = input.readUTF(),
                            value = input.readUTF(),
                            eligibleAfterTurn = input.readInt(),
                            priority = input.readInt(),
                            used = input.readBoolean()
                        )
                    )
                }
            }

            val transcript = buildList {
                repeat(input.readInt().coerceIn(0, 200)) {
                    add(
                        TranscriptItem(
                            id = input.readUTF(),
                            role = Role.valueOf(input.readUTF()),
                            text = input.readUTF(),
                            source = Source.valueOf(input.readUTF()),
                            reportable = input.readBoolean()
                        )
                    )
                }
            }

            val reported = buildSet {
                repeat(input.readInt().coerceIn(0, 200)) { add(input.readUTF()) }
            }

            val memory = SessionMemory(
                profile = profile,
                facts = facts,
                cues = cues,
                transcript = transcript,
                intensity = intensity,
                turnCount = turnCount,
                reportedResponseIds = reported,
                qualityInterventions = qualityInterventions
            )
            SessionSnapshotPolicy.sanitize(
                SessionSnapshot(
                    schemaVersion = schema,
                    state = SessionState(
                        phase = phase,
                        memory = memory,
                        contactEstablished = contactEstablished,
                        closedCleanly = closedCleanly
                    )
                )
            )
        }
    }.getOrNull()

    private fun writeProfile(out: DataOutputStream, profile: SpiritProfile) {
        out.writeUTF(profile.id)
        out.writeUTF(profile.displayName)
        out.writeUTF(profile.temperament.name)
        out.writeInt(profile.lexicon.size)
        profile.lexicon.forEach(out::writeUTF)
    }

    private fun readProfile(input: DataInputStream): SpiritProfile {
        val id = input.readUTF()
        val displayName = input.readUTF()
        val temperament = Temperament.valueOf(input.readUTF())
        val lexicon = buildSet {
            repeat(input.readInt().coerceIn(0, 128)) { add(input.readUTF()) }
        }
        return SpiritProfile(id, displayName, temperament, lexicon)
    }
}
