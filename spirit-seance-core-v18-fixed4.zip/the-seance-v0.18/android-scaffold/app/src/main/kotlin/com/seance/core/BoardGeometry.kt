package com.seance.core

data class BoardPoint(val x: Float, val y: Float) {
    init {
        require(x in 0f..1f) { "x must be normalized" }
        require(y in 0f..1f) { "y must be normalized" }
    }
}

/**
 * THE SÉANCE signature geometry: three narrowing letter bands around a central axis,
 * with YES/NO low on the board and GOODBYE forming the threshold at the bottom.
 * Pure Kotlin so motion remains unit-testable without Android/Compose.
 */
class BoardGeometry {
    private val bandOne = ('A'..'I').toList()
    private val bandTwo = ('J'..'R').toList()
    private val bandThree = ('S'..'Z').toList()
    private val digits = ('1'..'9').toList() + '0'

    fun positionFor(symbol: String): BoardPoint {
        val s = symbol.trim().uppercase()
        if (s == "YES") return BoardPoint(0.17f, 0.78f)
        if (s == "NO") return BoardPoint(0.83f, 0.78f)
        if (s == "GOODBYE") return BoardPoint(0.50f, 0.93f)
        if (s.length != 1) return BoardPoint(0.50f, 0.50f)

        val c = s[0]
        bandOne.indexOf(c).takeIf { it >= 0 }?.let { return BoardPoint(distribute(it, bandOne.size, 0.15f, 0.85f), 0.27f) }
        bandTwo.indexOf(c).takeIf { it >= 0 }?.let { return BoardPoint(distribute(it, bandTwo.size, 0.12f, 0.88f), 0.43f) }
        bandThree.indexOf(c).takeIf { it >= 0 }?.let { return BoardPoint(distribute(it, bandThree.size, 0.18f, 0.82f), 0.58f) }
        digits.indexOf(c).takeIf { it >= 0 }?.let { return BoardPoint(distribute(it, digits.size, 0.20f, 0.80f), 0.69f) }
        return BoardPoint(0.50f, 0.50f)
    }

    fun route(tokens: List<PlanchetteToken>): List<BoardPoint> = tokens.map { positionFor(it.symbol) }

    private fun distribute(index: Int, count: Int, min: Float, max: Float): Float {
        if (count <= 1) return (min + max) / 2f
        return min + (max - min) * index.toFloat() / (count - 1).toFloat()
    }
}
