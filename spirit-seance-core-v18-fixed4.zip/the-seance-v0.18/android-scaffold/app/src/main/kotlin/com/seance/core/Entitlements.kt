package com.seance.core

enum class AppTier { FREE, PRO }

enum class PremiumFeature {
    SECRET_HOST,
    ADVANCED_MEMORY,
    EXTENDED_HISTORY,
    PREMIUM_SPIRITS,
    PREMIUM_BOARDS
}

data class EntitlementPolicy(
    val tier: AppTier,
    val freeSessionTurnLimit: Int = 12,
    val freeHistoryLimit: Int = 8
) {
    fun has(feature: PremiumFeature): Boolean = when (feature) {
        PremiumFeature.SECRET_HOST,
        PremiumFeature.ADVANCED_MEMORY,
        PremiumFeature.EXTENDED_HISTORY,
        PremiumFeature.PREMIUM_SPIRITS,
        PremiumFeature.PREMIUM_BOARDS -> tier == AppTier.PRO
    }

    fun canContinue(turnCount: Int): Boolean =
        tier == AppTier.PRO || turnCount < freeSessionTurnLimit

    fun historyLimit(): Int = if (tier == AppTier.PRO) 100 else freeHistoryLimit
}
