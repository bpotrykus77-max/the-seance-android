package com.seance.core

/** Canonicalizes noisy store callbacks so stale/duplicate records cannot accidentally win. */
object PurchaseLedgerPolicy {
    fun canonical(purchases: List<PurchaseEntitlement>): List<PurchaseEntitlement> =
        purchases
            .groupBy { it.product }
            .mapNotNull { (_, records) ->
                records.maxWithOrNull(
                    compareBy<PurchaseEntitlement> { it.updatedAtEpochMs }
                        .thenBy { it.state.ordinal }
                        .thenBy { it.acknowledged }
                )
            }
            .sortedBy { it.product.id }
}
