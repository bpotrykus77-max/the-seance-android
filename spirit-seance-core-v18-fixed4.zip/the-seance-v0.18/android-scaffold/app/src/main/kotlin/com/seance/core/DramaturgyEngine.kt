package com.seance.core

class DramaturgyEngine {
    fun suggestedPhase(current: SessionPhase, turnCount: Int, intensity: Int): SessionPhase = when {
        current == SessionPhase.DIALOGUE && (turnCount >= 5 || intensity >= 35) -> SessionPhase.ESCALATION
        current == SessionPhase.ESCALATION && (turnCount >= 9 || intensity >= 75) -> SessionPhase.CLIMAX
        else -> current
    }

    fun intensityDelta(source: Source): Int = when (source) {
        Source.USER -> 3
        Source.AI -> 5
        Source.LOCAL_FALLBACK -> 2
        Source.HOST_OVERRIDE -> 8
        Source.MEMORY_CALLBACK -> 7
    }
}
