package com.seance.core

/**
 * Single entry point for a participant turn. It keeps provider orchestration out of the UI,
 * preserves memory callbacks and guarantees a local fallback when the primary provider fails.
 */
class SessionReplyCoordinator(
    private val orchestrator: ReplyOrchestrator
) {
    fun submit(
        director: SessionDirector,
        participantId: String,
        responseId: String,
        question: String,
        seed: Int = question.hashCode(),
        allowMemoryCallback: Boolean = true
    ): SpiritResponse? {
        val clean = question.trim().replace(Regex("\\s+"), " ").take(500)
        if (clean.isBlank()) return null

        director.participantSays(participantId, clean)

        if (allowMemoryCallback) {
            director.memoryCallback(responseId, clean)?.let { return it }
        }

        val state = director.state
        val request = ReplyRequest(
            question = clean,
            profile = state.memory.profile,
            phase = state.phase,
            recentTranscript = state.memory.transcript.takeLast(12)
        )
        val reply = orchestrator.reply(request, seed)
        return director.spiritReplies(responseId, reply.text, reply.source)
    }
}
