package com.seance.core

/** Store-neutral wrapper used by future remote providers. */
class CircuitBreakingReplyProvider(
    private val delegate: SpiritReplyProvider,
    private val breaker: ReplyCircuitBreaker = ReplyCircuitBreaker(),
    private val clockMs: () -> Long = { System.currentTimeMillis() }
) : SpiritReplyProvider {
    override fun generate(request: ReplyRequest): ProviderResult {
        val now = clockMs()
        if (!breaker.allowRequest(now)) return ProviderResult.Failure("provider_circuit_open")
        return when (val result = delegate.generate(request)) {
            is ProviderResult.Success -> {
                breaker.recordSuccess()
                result
            }
            is ProviderResult.Failure -> {
                breaker.recordFailure(now)
                result
            }
        }
    }

    fun circuitSnapshot(): CircuitSnapshot = breaker.snapshot(clockMs())
}
