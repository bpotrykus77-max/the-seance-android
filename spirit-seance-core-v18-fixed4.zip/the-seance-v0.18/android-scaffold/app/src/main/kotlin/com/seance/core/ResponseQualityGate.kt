package com.seance.core

data class QualityGateResult(
    val text: String,
    val adjusted: Boolean,
    val reason: String? = null
)

class ResponseQualityGate(
    private val recentWindow: Int = 6,
    private val maxLength: Int = 180
) {
    private val alternates = listOf("...", "ASK AGAIN", "I HEAR YOU", "NOT YET", "STAY")

    fun process(raw: String, transcript: List<TranscriptItem>, turnCount: Int): QualityGateResult {
        val normalized = raw.trim().replace(Regex("\\s+"), " ").take(maxLength)
        if (normalized.isBlank()) return QualityGateResult("...", true, "blank")

        val fingerprint = fingerprint(normalized)
        val recentSpirit = transcript.asReversed()
            .asSequence()
            .filter { it.role == Role.SPIRIT }
            .take(recentWindow)
            .map { fingerprint(it.text) }
            .toSet()

        if (fingerprint in recentSpirit) {
            val replacement = alternates[kotlin.math.abs(turnCount + fingerprint.hashCode()) % alternates.size]
            return QualityGateResult(replacement, true, "duplicate")
        }
        return QualityGateResult(normalized, false)
    }

    private fun fingerprint(text: String): String = text
        .lowercase()
        .replace(Regex("[^\\p{L}\\p{N}]+"), "")
        .take(120)
}
