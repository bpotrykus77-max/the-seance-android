package com.seance.core

data class ReplyRequest(
    val question: String,
    val profile: SpiritProfile,
    val phase: SessionPhase,
    val recentTranscript: List<TranscriptItem>
)

sealed interface ProviderResult {
    data class Success(val text: String) : ProviderResult
    data class Failure(val reason: String) : ProviderResult
}

fun interface SpiritReplyProvider {
    fun generate(request: ReplyRequest): ProviderResult
}

data class OrchestratedReply(val text: String, val source: Source, val degraded: Boolean)

/** Keeps network/AI providers out of UI and guarantees a local fallback path. */
class ReplyOrchestrator(
    private val primary: SpiritReplyProvider?,
    private val fallbackResponder: FallbackResponder = FallbackResponder()
) {
    fun reply(request: ReplyRequest, seed: Int): OrchestratedReply {
        if (primary != null) {
            val result = try { primary.generate(request) } catch (_: Throwable) { ProviderResult.Failure("exception") }
            if (result is ProviderResult.Success && result.text.isNotBlank()) {
                return OrchestratedReply(result.text, Source.AI, degraded = false)
            }
        }
        return OrchestratedReply(
            fallbackResponder.response(seed, request.phase),
            Source.LOCAL_FALLBACK,
            degraded = true
        )
    }
}
