package com.seance.core

data class PlanchetteToken(val symbol: String, val dwellMs: Long, val haptic: HapticCue)
enum class HapticCue { NONE, TICK, CONFIRM, EVENT }

class PlanchetteSequencer(private val maxTokens: Int = 64) {
    fun sequence(text: String): List<PlanchetteToken> {
        val normalized = text.trim().uppercase().replace(Regex("\\s+"), " ")
        if (normalized in setOf("YES", "NO", "GOODBYE", "GOOD BYE")) {
            return listOf(PlanchetteToken(if (normalized == "GOOD BYE") "GOODBYE" else normalized, 650, HapticCue.CONFIRM))
        }
        val cleaned = normalized.filter { it.isLetterOrDigit() || it == ' ' || it == '?' || it == '!' }.take(maxTokens)
        return cleaned.map { c ->
            when (c) {
                ' ' -> PlanchetteToken(" ", 120, HapticCue.NONE)
                '?', '!' -> PlanchetteToken(c.toString(), 260, HapticCue.EVENT)
                else -> PlanchetteToken(c.toString(), 280, HapticCue.TICK)
            }
        }
    }
}
