package com.seance.core

data class InputDecision(val accepted: Boolean, val normalized: String, val reason: String? = null)

/** Pure, deterministic validation used before a turn enters memory or any remote provider. */
class SessionInputPolicy(
    private val maxChars: Int = 180,
    private val maxRepeatedCharRun: Int = 10,
    private val maxWords: Int = 36
) {
    fun evaluate(raw: String): InputDecision {
        val normalized = raw
            .filter { it == '\n' || it == '\t' || !it.isISOControl() }
            .trim()
            .replace(Regex("\\s+"), " ")
            .take(maxChars)
        if (normalized.isBlank()) return InputDecision(false, "", "blank")
        if (Regex("(.)\\1{$maxRepeatedCharRun,}", RegexOption.IGNORE_CASE).containsMatchIn(normalized)) {
            return InputDecision(false, normalized, "repeated_characters")
        }
        if (normalized.split(" ").count { it.isNotBlank() } > maxWords) {
            return InputDecision(false, normalized, "too_many_words")
        }
        return InputDecision(true, normalized)
    }
}
