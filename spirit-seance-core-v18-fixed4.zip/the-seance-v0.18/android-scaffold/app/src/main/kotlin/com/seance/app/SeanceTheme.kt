package com.seance.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp

private val SeanceColors = darkColorScheme(
    primary = Color(0xFFC9A258),
    onPrimary = Color(0xFF0A0805),
    primaryContainer = Color(0xFF2A2113),
    onPrimaryContainer = Color(0xFFF0D99F),
    secondary = Color(0xFFE7D1A2),
    onSecondary = Color(0xFF171109),
    background = Color(0xFF070604),
    onBackground = Color(0xFFE7D1A2),
    surface = Color(0xFF171109),
    onSurface = Color(0xFFE7D1A2),
    surfaceVariant = Color(0xFF21170C),
    onSurfaceVariant = Color(0xFF9A8C76),
    outline = Color(0xFF8F7444),
    error = Color(0xFFD99696),
    onError = Color(0xFF210707)
)

private val SeanceTypography = Typography(
    headlineLarge = TextStyle(fontFamily = FontFamily.Serif, fontSize = 34.sp, letterSpacing = 1.2.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.Serif, fontSize = 28.sp, letterSpacing = 1.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.Serif, fontSize = 18.sp, letterSpacing = 0.6.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 16.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 12.sp)
)

@Composable
fun SeanceTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SeanceColors,
        typography = SeanceTypography,
        content = content
    )
}
