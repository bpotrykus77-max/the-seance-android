package com.seance.core

enum class CircuitState { CLOSED, OPEN, HALF_OPEN }

data class CircuitSnapshot(
    val state: CircuitState,
    val consecutiveFailures: Int,
    val openedAtMs: Long?
)

/**
 * Prevents a failing remote provider from being hammered repeatedly during a séance.
 * After the cool-down one probe is allowed (HALF_OPEN); success fully resets the circuit.
 */
class ReplyCircuitBreaker(
    private val failureThreshold: Int = 3,
    private val openDurationMs: Long = 30_000L
) {
    init {
        require(failureThreshold >= 1)
        require(openDurationMs > 0)
    }

    private var failures = 0
    private var openedAt: Long? = null
    private var probeInFlight = false

    fun allowRequest(nowMs: Long): Boolean {
        val opened = openedAt ?: return true
        if (nowMs < opened) {
            reset()
            return true
        }
        if (nowMs - opened < openDurationMs) return false
        if (probeInFlight) return false
        probeInFlight = true
        return true
    }

    fun recordSuccess() = reset()

    fun recordFailure(nowMs: Long) {
        probeInFlight = false
        failures += 1
        if (failures >= failureThreshold) openedAt = nowMs
    }

    fun snapshot(nowMs: Long): CircuitSnapshot {
        val opened = openedAt
        val state = when {
            opened == null -> CircuitState.CLOSED
            nowMs >= opened && nowMs - opened >= openDurationMs -> CircuitState.HALF_OPEN
            else -> CircuitState.OPEN
        }
        return CircuitSnapshot(state, failures, opened)
    }

    private fun reset() {
        failures = 0
        openedAt = null
        probeInFlight = false
    }
}
