package com.seance.core

enum class StoreProduct(val id: String) {
    PRO_LIFETIME("pro_lifetime")
}

enum class PurchaseState { NOT_OWNED, PENDING, ACTIVE, REVOKED }

data class PurchaseEntitlement(
    val product: StoreProduct,
    val state: PurchaseState,
    val acknowledged: Boolean = false,
    val updatedAtEpochMs: Long = 0L
)

data class BillingSnapshot(
    val purchases: List<PurchaseEntitlement> = emptyList(),
    val storeReachable: Boolean = true
)

/** Store-neutral resolver for the single paid product: PRO Lifetime. */
class EntitlementResolver {
    private fun latest(snapshot: BillingSnapshot): PurchaseEntitlement? =
        PurchaseLedgerPolicy.canonical(snapshot.purchases)
            .filter { it.product == StoreProduct.PRO_LIFETIME }
            .maxWithOrNull(compareBy<PurchaseEntitlement> { it.updatedAtEpochMs }.thenBy { it.state.ordinal })

    fun tier(snapshot: BillingSnapshot): AppTier {
        val current = latest(snapshot)
        return if (current?.state == PurchaseState.ACTIVE && current.acknowledged) AppTier.PRO else AppTier.FREE
    }

    fun needsAcknowledgement(snapshot: BillingSnapshot): Boolean {
        val current = latest(snapshot)
        return current?.state == PurchaseState.ACTIVE && !current.acknowledged
    }
}
