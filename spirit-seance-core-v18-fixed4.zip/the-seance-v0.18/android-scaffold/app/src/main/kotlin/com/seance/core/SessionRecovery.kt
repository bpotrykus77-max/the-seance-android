package com.seance.core

enum class RecoveryAction { RESTORE, SANITIZE_AND_RESTORE, DISCARD }

data class RecoveryDecision(val action: RecoveryAction, val issues: Set<String> = emptySet())

/** Decides whether a locally persisted session is safe to restore after process death. */
object SessionRecoveryPolicy {
    fun decide(snapshot: SessionSnapshot?): RecoveryDecision {
        if (snapshot == null) return RecoveryDecision(RecoveryAction.DISCARD, setOf("missing_snapshot"))
        if (snapshot.schemaVersion != SessionSnapshot.CURRENT_SCHEMA) {
            return RecoveryDecision(RecoveryAction.DISCARD, setOf("unsupported_schema"))
        }
        val health = SessionHealthMonitor.inspect(snapshot.state)
        if (health.healthy) return RecoveryDecision(RecoveryAction.RESTORE)
        val recoverable = setOf("intensity_out_of_range", "negative_turn_count", "transcript_oversized")
        return if (health.issues.all { it in recoverable }) {
            RecoveryDecision(RecoveryAction.SANITIZE_AND_RESTORE, health.issues)
        } else {
            RecoveryDecision(RecoveryAction.DISCARD, health.issues)
        }
    }

    fun recover(snapshot: SessionSnapshot?): SessionSnapshot? = when (decide(snapshot).action) {
        RecoveryAction.RESTORE -> snapshot
        RecoveryAction.SANITIZE_AND_RESTORE -> snapshot?.let(SessionSnapshotPolicy::sanitize)
        RecoveryAction.DISCARD -> null
    }
}
