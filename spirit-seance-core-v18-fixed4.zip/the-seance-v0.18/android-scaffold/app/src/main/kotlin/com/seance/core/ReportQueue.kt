package com.seance.core

data class ResponseReport(
    val responseId: String,
    val category: String,
    val createdAtEpochMs: Long
)

class ReportQueue(private val maxPending: Int = 100) {
    private val reports = mutableListOf<ResponseReport>()
    private val allowedCategories = setOf("unsafe", "harassment", "sexual", "self_harm", "hate", "incorrect", "other", "user_report")

    fun add(responseId: String, category: String, createdAtEpochMs: Long = System.currentTimeMillis()): ResponseReport {
        val normalizedCategory = category.trim().lowercase().replace('-', '_')
        val safeCategory = normalizedCategory.takeIf { it in allowedCategories } ?: "other"
        val report = ResponseReport(responseId.trim().take(80), safeCategory, createdAtEpochMs)
        reports.removeAll { it.responseId == report.responseId }
        reports += report
        while (reports.size > maxPending) reports.removeAt(0)
        return report
    }

    fun pending(): List<ResponseReport> = reports.toList()

    fun acknowledge(responseIds: Set<String>): Int {
        val before = reports.size
        reports.removeAll { it.responseId in responseIds }
        return before - reports.size
    }
}
