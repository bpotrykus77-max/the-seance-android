package com.seance.core

enum class RestoreDisposition { PRO_RESTORED, FREE_CONFIRMED, RETRY_REQUIRED }

data class RestoreResult(
    val disposition: RestoreDisposition,
    val tier: AppTier,
    val messageCode: String? = null
)

/** Interprets a fresh store query used by the "restore purchases" flow. */
class PurchaseRestorePolicy(private val resolver: EntitlementResolver = EntitlementResolver()) {
    fun evaluate(snapshot: BillingSnapshot): RestoreResult {
        if (!snapshot.storeReachable) {
            return RestoreResult(RestoreDisposition.RETRY_REQUIRED, AppTier.FREE, "store_unreachable")
        }
        if (resolver.needsAcknowledgement(snapshot)) {
            return RestoreResult(RestoreDisposition.RETRY_REQUIRED, AppTier.FREE, "acknowledgement_required")
        }
        return if (resolver.tier(snapshot) == AppTier.PRO) {
            RestoreResult(RestoreDisposition.PRO_RESTORED, AppTier.PRO)
        } else {
            RestoreResult(RestoreDisposition.FREE_CONFIRMED, AppTier.FREE)
        }
    }
}
