package com.seance.core

class SessionDirector(
    initialProfile: SpiritProfile,
    private val safety: SafetyFilter = ConservativeSafetyFilter(),
    private val memoryEngine: MemoryEngine = MemoryEngine(),
    private val fallbackResponder: FallbackResponder = FallbackResponder(),
    private val dramaturgy: DramaturgyEngine = DramaturgyEngine(),
    private val reports: ReportQueue = ReportQueue(),
    private val qualityGate: ResponseQualityGate = ResponseQualityGate()
) {
    var state = SessionState(memory = SessionMemory(initialProfile))
        private set

    fun snapshot(): SessionSnapshot = SessionSnapshotPolicy.sanitize(SessionSnapshot(state = state))

    fun restore(snapshot: SessionSnapshot) {
        state = SessionSnapshotPolicy.sanitize(snapshot).state
    }

    fun begin() {
        require(state.phase == SessionPhase.IDLE)
        state = state.copy(phase = SessionPhase.INVOCATION)
        system("The room grows quiet.")
    }

    fun establishContact() {
        require(state.phase == SessionPhase.INVOCATION)
        state = state.copy(phase = SessionPhase.CONTACT, contactEstablished = true)
        system("Contact established.")
    }

    fun enterDialogue() {
        require(state.phase == SessionPhase.CONTACT)
        state = state.copy(phase = SessionPhase.DIALOGUE)
    }

    fun participantSays(id: String, text: String) {
        require(state.phase in activeDialoguePhases)
        val clean = text.trim().replace(Regex("\\s+"), " ").take(500)
        if (clean.isBlank()) return
        state = state.copy(memory = memoryEngine.observeParticipant(state.memory, clean))
        append(TranscriptItem(id, Role.PARTICIPANT, clean, Source.USER))
        autoIntensity(dramaturgy.intensityDelta(Source.USER))
        autoAdvance()
    }

    fun spiritReplies(id: String, raw: String, source: Source = Source.AI): SpiritResponse {
        require(state.phase in activeReplyPhases)
        val safe = safety.sanitize(raw)
        val quality = qualityGate.process(safe.text, state.memory.transcript, state.memory.turnCount)
        if (quality.adjusted) {
            state = state.copy(memory = state.memory.copy(qualityInterventions = state.memory.qualityInterventions + 1))
        }
        val response = SpiritResponse(id, quality.text, source, reportable = source == Source.AI)
        append(TranscriptItem(id, Role.SPIRIT, response.text, source, response.reportable))
        autoIntensity(dramaturgy.intensityDelta(source))
        autoAdvance()
        return response
    }

    fun memoryCallback(id: String, triggerText: String = ""): SpiritResponse? {
        require(state.phase in activeDialoguePhases)
        val callback = memoryEngine.nextCallback(state.memory, triggerText) ?: return null
        state = state.copy(memory = callback.first)
        return spiritReplies(id, callback.second, Source.MEMORY_CALLBACK)
    }

    fun localFallback(id: String, seed: Int): SpiritResponse =
        spiritReplies(id, fallbackResponder.response(seed, state.phase), Source.LOCAL_FALLBACK)

    fun reportResponse(responseId: String, category: String): Boolean {
        val item = state.memory.transcript.firstOrNull { it.id == responseId } ?: return false
        if (!item.reportable) return false
        reports.add(responseId, category)
        state = state.copy(memory = state.memory.copy(reportedResponseIds = state.memory.reportedResponseIds + responseId))
        return true
    }

    fun pendingReports(): List<ResponseReport> = reports.pending()

    fun acknowledgeReports(responseIds: Set<String>): Int = reports.acknowledge(responseIds)

    fun applyHostDirective(id: String, directive: HostDirective): SpiritResponse? = when (directive) {
        is HostDirective.ForceReply -> spiritReplies(id, directive.text, Source.HOST_OVERRIDE)
        is HostDirective.InjectFact -> {
            state = state.copy(memory = memoryEngine.injectFact(state.memory, directive.key, directive.value))
            null
        }
        is HostDirective.SetIntensity -> {
            state = state.copy(memory = state.memory.copy(intensity = directive.value.coerceIn(0, 100)))
            autoAdvance()
            null
        }
        HostDirective.ForceClimax -> {
            state = state.copy(phase = SessionPhase.CLIMAX, memory = state.memory.copy(intensity = maxOf(85, state.memory.intensity)))
            null
        }
        HostDirective.ForceClosing -> {
            state = state.copy(phase = SessionPhase.CLOSING)
            null
        }
    }

    fun escalate() {
        require(state.phase == SessionPhase.DIALOGUE)
        state = state.copy(phase = SessionPhase.ESCALATION)
        autoIntensity(15)
    }

    fun climax() {
        require(state.phase in setOf(SessionPhase.DIALOGUE, SessionPhase.ESCALATION))
        state = state.copy(phase = SessionPhase.CLIMAX, memory = state.memory.copy(intensity = maxOf(85, state.memory.intensity)))
    }

    fun close() {
        require(state.phase != SessionPhase.ENDED)
        state = state.copy(phase = SessionPhase.CLOSING)
    }

    fun end() {
        require(state.phase == SessionPhase.CLOSING)
        system("Session closed.")
        state = state.copy(phase = SessionPhase.ENDED, closedCleanly = true)
    }

    private fun autoAdvance() {
        val next = dramaturgy.suggestedPhase(state.phase, state.memory.turnCount, state.memory.intensity)
        if (next != state.phase) state = state.copy(phase = next)
    }

    private fun autoIntensity(delta: Int) {
        state = state.copy(memory = state.memory.copy(intensity = (state.memory.intensity + delta).coerceIn(0, 100)))
    }

    private fun system(text: String) {
        append(TranscriptItem("system-${state.memory.transcript.size}", Role.SYSTEM, text, Source.LOCAL_FALLBACK))
    }

    private fun append(item: TranscriptItem) {
        state = state.copy(memory = state.memory.copy(transcript = state.memory.transcript + item))
    }

    private companion object {
        val activeDialoguePhases = setOf(SessionPhase.DIALOGUE, SessionPhase.ESCALATION, SessionPhase.CLIMAX)
        val activeReplyPhases = activeDialoguePhases + SessionPhase.CLOSING
    }
}
