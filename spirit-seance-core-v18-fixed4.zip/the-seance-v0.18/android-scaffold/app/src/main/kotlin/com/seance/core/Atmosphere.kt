package com.seance.core

enum class AtmosphereCue {
    ROOM_TONE,
    CONTACT_PULSE,
    WHISPER_RISE,
    HEARTBEAT_LOW,
    CLIMAX_SWELL,
    CLOSING_BELL,
    SILENCE
}

data class AtmosphereFrame(
    val cue: AtmosphereCue,
    val volume: Float,
    val haptic: HapticCue = HapticCue.NONE
)

/** Pure decision layer. Android audio playback can consume these frames without owning séance logic. */
class AtmosphereDirector {
    fun frame(phase: SessionPhase, intensity: Int, source: Source? = null): AtmosphereFrame {
        val i = intensity.coerceIn(0, 100)
        return when (phase) {
            SessionPhase.IDLE -> AtmosphereFrame(AtmosphereCue.SILENCE, 0f)
            SessionPhase.INVOCATION -> AtmosphereFrame(AtmosphereCue.ROOM_TONE, 0.16f)
            SessionPhase.CONTACT -> AtmosphereFrame(AtmosphereCue.CONTACT_PULSE, 0.26f, HapticCue.CONFIRM)
            SessionPhase.DIALOGUE -> {
                val cue = if (source == Source.MEMORY_CALLBACK || source == Source.HOST_OVERRIDE) AtmosphereCue.WHISPER_RISE else AtmosphereCue.ROOM_TONE
                AtmosphereFrame(cue, 0.18f + (i / 100f) * 0.12f, if (source == Source.HOST_OVERRIDE) HapticCue.EVENT else HapticCue.NONE)
            }
            SessionPhase.ESCALATION -> AtmosphereFrame(AtmosphereCue.HEARTBEAT_LOW, 0.25f + (i / 100f) * 0.20f, HapticCue.TICK)
            SessionPhase.CLIMAX -> AtmosphereFrame(AtmosphereCue.CLIMAX_SWELL, 0.58f, HapticCue.EVENT)
            SessionPhase.CLOSING -> AtmosphereFrame(AtmosphereCue.CLOSING_BELL, 0.30f, HapticCue.CONFIRM)
            SessionPhase.ENDED -> AtmosphereFrame(AtmosphereCue.SILENCE, 0f)
        }
    }
}
