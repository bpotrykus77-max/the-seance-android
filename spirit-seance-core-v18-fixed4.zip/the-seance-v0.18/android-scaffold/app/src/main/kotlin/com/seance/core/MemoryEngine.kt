package com.seance.core

class MemoryEngine(
    private val callbackPolicy: CallbackPolicy = CallbackPolicy()
) {
    private val namePatterns = listOf(
        Regex("(?i)\\bmy name is\\s+([\\p{L}][\\p{L}'-]{1,30})"),
        Regex("(?i)\\bi am called\\s+([\\p{L}][\\p{L}'-]{1,30})"),
        Regex("(?i)\\bich hei(?:ß|ss)e\\s+([\\p{L}][\\p{L}'-]{1,30})"),
        Regex("(?i)\\bmein name ist\\s+([\\p{L}][\\p{L}'-]{1,30})"),
        Regex("(?i)\\bmam na imi(?:ę|e)\\s+([\\p{L}][\\p{L}'-]{1,30})"),
        Regex("(?i)\\bnazywam si(?:ę|e)\\s+([\\p{L}][\\p{L}'-]{1,30})")
    )

    fun observeParticipant(memory: SessionMemory, text: String): SessionMemory {
        val nextTurn = memory.turnCount + 1
        var updated = memory.copy(turnCount = nextTurn)
        val name = namePatterns.asSequence()
            .mapNotNull { it.find(text)?.groupValues?.getOrNull(1) }
            .firstOrNull()
            ?.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }

        if (name != null) {
            updated = upsert(
                memory = updated,
                key = "participant_name",
                value = name,
                importance = 95,
                delayTurns = 2
            )
        }
        return updated
    }

    fun injectFact(memory: SessionMemory, key: String, value: String, importance: Int = 80): SessionMemory {
        val normalizedKey = key.trim().lowercase().replace(Regex("[^a-z0-9_]+"), "_").trim('_')
        val normalizedValue = value.trim().replace(Regex("\\s+"), " ").take(80)
        if (normalizedKey.isBlank() || normalizedValue.isBlank()) return memory
        return upsert(memory, normalizedKey, normalizedValue, importance.coerceIn(1, 100), if (normalizedKey.startsWith("host_")) 3 else 1)
    }

    private fun upsert(memory: SessionMemory, key: String, value: String, importance: Int, delayTurns: Int): SessionMemory {
        val previous = memory.facts[key]
        val fact = MemoryFact(
            key = key,
            value = value,
            confidence = 1.0,
            firstSeenTurn = previous?.firstSeenTurn ?: memory.turnCount,
            lastUsedTurn = previous?.lastUsedTurn,
            importance = importance
        )
        val cue = MemoryCue(
            key = key,
            value = value,
            eligibleAfterTurn = memory.turnCount + delayTurns,
            priority = importance
        )
        return memory.copy(
            facts = memory.facts + (key to fact),
            cues = memory.cues.filterNot { it.key == key && !it.used } + cue
        )
    }

    fun nextCallback(memory: SessionMemory, question: String = ""): Pair<SessionMemory, String>? {
        val eligible = memory.cues.withIndex()
            .filter { (_, cue) -> callbackPolicy.shouldSurface(memory, cue, question) }
            .maxWithOrNull(compareBy<IndexedValue<MemoryCue>> { it.value.priority }
                .thenBy { -it.value.eligibleAfterTurn }) ?: return null

        val cue = eligible.value
        val text = "${cue.value.uppercase()}..."
        val newCues = memory.cues.toMutableList().also {
            it[eligible.index] = cue.copy(used = true)
        }
        val newFacts = memory.facts[cue.key]?.let { fact ->
            memory.facts + (cue.key to fact.copy(lastUsedTurn = memory.turnCount))
        } ?: memory.facts
        return memory.copy(cues = newCues, facts = newFacts) to text
    }
}
