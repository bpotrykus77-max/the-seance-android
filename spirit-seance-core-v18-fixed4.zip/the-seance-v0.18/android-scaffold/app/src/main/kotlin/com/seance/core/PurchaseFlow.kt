package com.seance.core

enum class PurchaseUiState { IDLE, LOADING, PENDING, OWNED, ERROR }

data class PurchaseFlowState(
    val uiState: PurchaseUiState = PurchaseUiState.IDLE,
    val tier: AppTier = AppTier.FREE,
    val messageCode: String? = null
)

/** Store-neutral reducer. Platform billing adapters feed snapshots into this reducer. */
class PurchaseFlowReducer(private val resolver: EntitlementResolver = EntitlementResolver()) {
    fun from(snapshot: BillingSnapshot): PurchaseFlowState {
        val tier = resolver.tier(snapshot)
        if (tier == AppTier.PRO) return PurchaseFlowState(PurchaseUiState.OWNED, AppTier.PRO)
        if (!snapshot.storeReachable) return PurchaseFlowState(PurchaseUiState.ERROR, AppTier.FREE, "store_unreachable")
        if (resolver.needsAcknowledgement(snapshot)) return PurchaseFlowState(PurchaseUiState.LOADING, AppTier.FREE, "acknowledgement_required")
        val latest = PurchaseLedgerPolicy.canonical(snapshot.purchases)
            .filter { it.product == StoreProduct.PRO_LIFETIME }
            .maxWithOrNull(compareBy<PurchaseEntitlement> { it.updatedAtEpochMs }.thenBy { it.state.ordinal })
        return when (latest?.state) {
            PurchaseState.PENDING -> PurchaseFlowState(PurchaseUiState.PENDING, AppTier.FREE, "purchase_pending")
            PurchaseState.REVOKED -> PurchaseFlowState(PurchaseUiState.IDLE, AppTier.FREE, "purchase_revoked")
            PurchaseState.ACTIVE -> PurchaseFlowState(PurchaseUiState.LOADING, AppTier.FREE, "acknowledgement_required")
            PurchaseState.NOT_OWNED, null -> PurchaseFlowState(PurchaseUiState.IDLE, AppTier.FREE)
        }
    }
}
