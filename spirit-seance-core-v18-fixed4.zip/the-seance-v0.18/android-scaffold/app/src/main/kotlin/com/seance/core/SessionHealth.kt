package com.seance.core

data class SessionHealth(
    val healthy: Boolean,
    val issues: Set<String> = emptySet()
)

object SessionHealthMonitor {
    fun inspect(state: SessionState): SessionHealth {
        val issues = linkedSetOf<String>()
        if (state.memory.intensity !in 0..100) issues += "intensity_out_of_range"
        if (state.memory.turnCount < 0) issues += "negative_turn_count"
        if (state.contactEstablished && state.phase in setOf(SessionPhase.IDLE, SessionPhase.INVOCATION)) issues += "contact_phase_mismatch"
        if (state.closedCleanly && state.phase != SessionPhase.ENDED) issues += "closed_phase_mismatch"
        if (state.memory.transcript.size > 200) issues += "transcript_oversized"
        return SessionHealth(issues.isEmpty(), issues)
    }
}
