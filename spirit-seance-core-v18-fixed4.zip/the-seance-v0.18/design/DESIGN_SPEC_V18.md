# THE SÉANCE — Visual Signature v0.18

Status: IMPLEMENTED IN UI STRUCTURE / DEVICE VALIDATION PENDING

## Signature rules
- Board uses three narrowing letter bands: A–I / J–R / S–Z.
- YES and NO sit below the letter arena; GOODBYE forms the lower threshold.
- Base palette remains near-black + aged gold.
- Mystical violet is a response-only accent, not the base brand color.
- Living Board intensity follows séance phase and session intensity.
- Planchette uses a taller seal/drop silhouette rather than a generic pill/cursor.
- Participant UI must never expose provider, source, host override, or debug state.

## Motion signature
Attract → hesitate → micro-movement → commit → land.
Do not use constant-speed linear cursor motion.

## Brand principle
The board must be recognizable from silhouette and composition even without the logo.

## Reference
`visual-direction-v18.png` is directional art, not a pixel-perfect implementation contract.
