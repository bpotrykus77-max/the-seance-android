# THE SÉANCE v0.18 — Android build compile fix

Observed in GitHub Actions build #5 during `:app:lintDebug` / `:app:compileDebugKotlin`:

- inaccessible `androidx.compose.foundation.layout.weight` resolution
- unresolved `sp` references in `MainActivity.kt`

Corrections applied:

- removed the direct `layout.weight` import and eliminated the two `Modifier.weight(...)` usages
- intensity meter now uses a responsive `BoxWithConstraints` segment width
- the single Secret Host climax button uses `fillMaxWidth()` instead of weight
- imported `androidx.compose.ui.unit.sp` and converted letter spacing to idiomatic `1.5.sp`, `1.6.sp`, `1.1.sp`
- embedded GitHub Actions workflow updated with the successful ZIP preflight fix and current checkout/setup-java actions

Validation in the local tool environment:

- pure Kotlin core recompiled with `kotlinc`
- `CoreSelfTestV18` passed: `ALL CORE V18 SELF-TESTS PASSED`
- static check confirms no remaining `layout.weight`, `Modifier.weight(...)`, or `androidx.compose.ui.unit.sp(...)` misuse in `MainActivity.kt`

Full Android compilation still requires the GitHub Actions Android environment and is not claimed as passed until CI succeeds.

## Build #6 dependency metadata fix

Observed in GitHub Actions build #6 during `:app:lintDebug`:

- `androidx.compose.runtime:runtime-saveable-android:1.12.0` requires Android Gradle Plugin 9.1.0 or higher
- project still declared Android Gradle Plugin 9.0.1

Correction applied:

- upgraded `com.android.application` from 9.0.1 to 9.1.0 in `android-scaffold/build.gradle.kts`
- kept Gradle 9.1.0 in CI, matching the currently configured workflow

This change is statically verified in the package. A full Android build is still not claimed until GitHub Actions completes successfully.


## Build #8 fix – API 37 / AAR metadata

GitHub Actions Build #8 reached Android AAR metadata validation. Compose BOM 2026.08.00 resolves libraries that require compileSdk 37. The project was still on compileSdk 36 and AGP 9.1.0.

Applied minimal compatibility update:
- Android Gradle Plugin: 9.1.0 -> 9.2.1
- compileSdk: 36 -> 37
- targetSdk remains 36 (no target behavior change in this build gate)
- CI Gradle: 9.4.1
- CI release invariant updated to compileSdk 37 / targetSdk 36

This is a build compatibility fix, not a production-readiness claim. A full Android build still needs to succeed in CI.
