package com.seance.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import com.seance.core.AppTier
import com.seance.core.BoardGeometry
import com.seance.core.EntitlementPolicy
import com.seance.core.HapticCue
import com.seance.core.HostDirective
import com.seance.core.HostAccessGate
import com.seance.core.HostDirectivePolicy
import com.seance.core.PlanchettePlayback
import com.seance.core.Role
import com.seance.core.ReplyOrchestrator
import com.seance.core.SessionInputPolicy
import com.seance.core.SessionReplyCoordinator
import com.seance.core.SessionDirector
import com.seance.core.SessionPhase
import com.seance.core.Source
import com.seance.core.SpiritProfile
import com.seance.core.Temperament
import java.util.UUID
import kotlinx.coroutines.delay

private val Ink = Color(0xFF070604)
private val DeepInk = Color(0xFF0E0B07)
private val Panel = Color(0xFF171109)
private val PanelLift = Color(0xFF21170C)
private val Gold = Color(0xFFC9A258)
private val BrightGold = Color(0xFFF0D99F)
private val PaleGold = Color(0xFFE7D1A2)
private val Muted = Color(0xFF9A8C76)
private val Danger = Color(0xFF8D3535)
private val Wine = Color(0xFF2A1010)
private val VeilViolet = Color(0xFF6D3D86)
private val VeilVioletBright = Color(0xFFB885D0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SeanceTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
                    SeanceApp()
                }
            }
        }
    }
}

@Composable
private fun SeanceApp() {
    val context = LocalContext.current
    val store = remember { PersistentSessionStore(context) }
    var director by remember {
        mutableStateOf(
            newDirector().also { candidate -> store.load()?.let(candidate::restore) }
        )
    }
    var refresh by remember { mutableStateOf(0) }
    var question by remember { mutableStateOf("") }
    var hostPanel by remember { mutableStateOf(false) }
    val hostAccessGate = remember { HostAccessGate() }
    var tier by remember { mutableStateOf(AppTier.FREE) }
    var planchetteSymbol by remember { mutableStateOf("") }
    val haptics = LocalHapticFeedback.current
    @Suppress("UNUSED_VARIABLE") val renderKey = refresh

    fun persist() {
        store.save(director.snapshot())
    }

    fun mutate(block: (SessionDirector) -> Unit) {
        block(director)
        persist()
        refresh++
    }

    val state = director.state
    val lastSpirit = state.memory.transcript.lastOrNull { it.role == Role.SPIRIT }
    val entitlement = EntitlementPolicy(tier)
    val playback = remember { PlanchettePlayback() }
    val inputPolicy = remember { SessionInputPolicy() }
    val replyCoordinator = remember { SessionReplyCoordinator(ReplyOrchestrator(primary = null)) }

    LaunchedEffect(lastSpirit?.id) {
        planchetteSymbol = ""
        val response = lastSpirit?.let { com.seance.core.SpiritResponse(it.id, it.text, it.source, it.reportable) }
        playback.frames(response).forEach { frame ->
            planchetteSymbol = frame.symbol
            when (frame.haptic) {
                HapticCue.TICK -> haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                HapticCue.CONFIRM, HapticCue.EVENT -> haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                HapticCue.NONE -> Unit
            }
            delay(frame.delayMs)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Ink, DeepInk, Ink)))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 22.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            stringResource(R.string.app_name),
            color = BrightGold,
            style = MaterialTheme.typography.headlineLarge,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    if (hostAccessGate.registerTap(System.currentTimeMillis(), tier)) {
                        hostPanel = true
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    }
                },
            textAlign = TextAlign.Center
        )
        Text(
            stringResource(R.string.tagline),
            color = Muted,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        StatusStrip(
            stringResource(phaseLabelRes(state.phase)),
            state.memory.intensity,
            state.memory.profile.displayName,
            if (tier == AppTier.PRO) stringResource(R.string.pro_mode) else stringResource(R.string.free_mode)
        )
        IntensityMeter(state.memory.intensity)
        VeilStatus(state.memory.intensity, state.phase)
        if (state.phase in setOf(SessionPhase.DIALOGUE, SessionPhase.ESCALATION, SessionPhase.CLIMAX)) {
            SessionLiveChip()
        }
        SpiritBoard(lastSpirit?.text ?: stringResource(phasePromptRes(state.phase)), planchetteSymbol, state.phase, state.memory.intensity)

        if (lastSpirit?.reportable == true) {
            val alreadyReported = lastSpirit.id in state.memory.reportedResponseIds
            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                enabled = !alreadyReported,
                onClick = { mutate { it.reportResponse(lastSpirit.id, "user_report") } }
            ) {
                Text(if (alreadyReported) stringResource(R.string.response_reported) else stringResource(R.string.report_ai_response))
            }
        }

        Text(
            stringResource(R.string.entertainment_notice),
            color = Muted,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        when (state.phase) {
            SessionPhase.IDLE, SessionPhase.INVOCATION, SessionPhase.CONTACT -> {
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink),
                    onClick = {
                        mutate {
                            when (it.state.phase) {
                                SessionPhase.IDLE -> it.begin()
                                SessionPhase.INVOCATION -> it.establishContact()
                                SessionPhase.CONTACT -> it.enterDialogue()
                                else -> Unit
                            }
                        }
                    }
                ) { Text(primaryLabelRes(state.phase).let { stringResource(it) }, fontWeight = FontWeight.Bold) }
            }

            SessionPhase.DIALOGUE, SessionPhase.ESCALATION, SessionPhase.CLIMAX -> {
                OutlinedTextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = question,
                    onValueChange = { question = it.take(180) },
                    label = { Text(stringResource(R.string.ask_question)) },
                    singleLine = false
                )
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = question.isNotBlank() && entitlement.canContinue(state.memory.turnCount),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink),
                    onClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        val decision = inputPolicy.evaluate(question)
                        if (!decision.accepted) return@Button
                        question = ""
                        mutate {
                            replyCoordinator.submit(
                                director = it,
                                participantId = UUID.randomUUID().toString(),
                                responseId = UUID.randomUUID().toString(),
                                question = decision.normalized
                            )
                        }
                    }
                ) { Text(stringResource(R.string.send_question), fontWeight = FontWeight.Bold) }
                if (!entitlement.canContinue(state.memory.turnCount)) {
                    Text(stringResource(R.string.free_limit_reached), color = Color(0xFFD99696), style = MaterialTheme.typography.bodySmall)
                    ProUpsellCard()
                }
            }

            SessionPhase.CLOSING -> Button(
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink),
                onClick = { mutate { it.end() } }
            ) { Text(stringResource(R.string.goodbye)) }

            SessionPhase.ENDED -> OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    store.clear()
                    director = newDirector()
                    refresh++
                }
            ) { Text(stringResource(R.string.new_seance)) }
        }

        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            enabled = state.phase !in setOf(SessionPhase.IDLE, SessionPhase.CLOSING, SessionPhase.ENDED),
            onClick = { mutate { it.close() } }
        ) { Text(stringResource(R.string.end_session)) }

        if (hostPanel && entitlement.has(com.seance.core.PremiumFeature.SECRET_HOST)) SecretHostPanel(
            director = director,
            changed = { persist(); refresh++ },
            closePanel = { hostPanel = false }
        )
        TranscriptPanel(director, entitlement.historyLimit())
    }
}

@Composable
private fun StatusStrip(phase: String, intensity: Int, spirit: String, tierLabel: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(Panel, PanelLift, Panel)), RoundedCornerShape(14.dp))
            .border(1.dp, Gold.copy(alpha = 0.42f), RoundedCornerShape(14.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("✦ ${spirit.uppercase()}", color = BrightGold, fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold)
        Text(phase, color = Muted)
        Text("$intensity%  •  $tierLabel", color = PaleGold, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun IntensityMeter(intensity: Int) {
    val safe = intensity.coerceIn(0, 100)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel.copy(alpha = 0.56f), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.presence_label), color = Muted, style = MaterialTheme.typography.labelSmall)
            Text("$safe%", color = PaleGold, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val segmentWidth = (maxWidth - 36.dp) / 10
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(10) { index ->
                    val active = safe >= (index + 1) * 10
                    Box(
                        modifier = Modifier
                            .width(segmentWidth)
                            .height(4.dp)
                            .background(
                                if (active) Gold else Gold.copy(alpha = 0.12f),
                                RoundedCornerShape(50)
                            )
                    )
                }
            }
        }
    }
}


@Composable
private fun VeilStatus(intensity: Int, phase: SessionPhase) {
    val active = phase in setOf(SessionPhase.CONTACT, SessionPhase.DIALOGUE, SessionPhase.ESCALATION, SessionPhase.CLIMAX)
    val label = when {
        !active -> stringResource(R.string.veil_quiet)
        intensity >= 75 -> stringResource(R.string.veil_strong)
        intensity >= 40 -> stringResource(R.string.veil_present)
        else -> stringResource(R.string.veil_faint)
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel.copy(alpha = 0.46f), RoundedCornerShape(12.dp))
            .border(1.dp, Gold.copy(alpha = if (active) 0.36f else 0.16f), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("✧ ${stringResource(R.string.veil_label)}", color = Muted, style = MaterialTheme.typography.labelSmall)
        Text(label, color = if (active) PaleGold else Muted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SessionLiveChip() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Gold.copy(alpha = 0.08f), RoundedCornerShape(999.dp))
            .border(1.dp, Gold.copy(alpha = 0.28f), RoundedCornerShape(999.dp))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("✦  ${stringResource(R.string.session_live)}  ✦", color = PaleGold, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ProUpsellCard() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(PanelLift, Panel)), RoundedCornerShape(16.dp))
            .border(1.dp, Gold.copy(alpha = 0.58f), RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Text(stringResource(R.string.pro_lifetime_title), color = BrightGold, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.pro_lifetime_body), color = Muted, style = MaterialTheme.typography.bodySmall)
        Text(stringResource(R.string.pro_lifetime_benefits), color = PaleGold, style = MaterialTheme.typography.bodySmall)
        OutlinedButton(modifier = Modifier.fillMaxWidth(), enabled = false, onClick = {}) {
            Text(stringResource(R.string.purchase_available_after_store_setup))
        }
    }
}

@Composable
private fun SpiritBoard(message: String, currentSymbol: String, phase: SessionPhase, intensity: Int) {
    val geometry = remember { BoardGeometry() }
    val target = geometry.positionFor(currentSymbol)
    val animatedX by animateFloatAsState(targetValue = target.x, label = "planchette-x")
    val animatedY by animateFloatAsState(targetValue = target.y, label = "planchette-y")
    val planchetteScale by animateFloatAsState(targetValue = if (currentSymbol.isBlank()) 0.96f else 1.06f, label = "planchette-scale")
    var boardWidth by remember { mutableStateOf(1) }
    var boardHeight by remember { mutableStateOf(1) }
    val density = LocalDensity.current
    val planchetteWidthPx = with(density) { 92.dp.roundToPx() }
    val planchetteDescription = stringResource(R.string.planchette_description, currentSymbol.ifBlank { "…" })
    val planchetteHeightPx = with(density) { 62.dp.roundToPx() }
    val living = phase in setOf(SessionPhase.CONTACT, SessionPhase.DIALOGUE, SessionPhase.ESCALATION, SessionPhase.CLIMAX)
    val veilStrength = when (phase) {
        SessionPhase.CLIMAX -> 0.42f
        SessionPhase.ESCALATION -> 0.30f
        SessionPhase.DIALOGUE -> 0.20f
        SessionPhase.CONTACT -> 0.12f
        else -> 0.04f
    } + (intensity.coerceIn(0, 100) / 100f) * 0.08f

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(360.dp)
            .background(
                Brush.radialGradient(
                    listOf(
                        if (living) VeilViolet.copy(alpha = veilStrength) else PanelLift,
                        Panel,
                        Ink
                    )
                ),
                RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp, bottomStart = 18.dp, bottomEnd = 18.dp)
            )
            .border(1.dp, Gold.copy(alpha = 0.62f), RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp, bottomStart = 18.dp, bottomEnd = 18.dp))
            .padding(18.dp)
            .onSizeChanged {
                boardWidth = it.width
                boardHeight = it.height
            }
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("◌", color = Gold.copy(alpha = 0.52f), fontFamily = FontFamily.Serif)
            Text("✧", color = if (living) VeilVioletBright.copy(alpha = 0.78f) else Gold.copy(alpha = 0.42f), fontFamily = FontFamily.Serif)
        }
        Text(
            stringResource(R.string.between_worlds),
            color = Gold.copy(alpha = 0.62f),
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.5.sp,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 26.dp)
        )

        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("✦  ◇  ✦", color = if (living) VeilVioletBright.copy(alpha = 0.82f) else Gold.copy(alpha = 0.62f), fontFamily = FontFamily.Serif)
            Spacer(Modifier.height(10.dp))
            Text(
                "A B C D E F G H I\nJ K L M N O P Q R\nS T U V W X Y Z",
                color = PaleGold,
                fontFamily = FontFamily.Serif,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.titleMedium,
                letterSpacing = 1.6.sp
            )
            Spacer(Modifier.height(14.dp))
            Text("1 2 3 4 5 6 7 8 9 0", color = Gold, fontFamily = FontFamily.Serif)
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("◉  ${stringResource(R.string.yes)}", color = PaleGold, fontFamily = FontFamily.Serif)
                Text("${stringResource(R.string.no)}  ◉", color = PaleGold, fontFamily = FontFamily.Serif)
            }
            Spacer(Modifier.height(34.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Ink.copy(alpha = 0.32f), RoundedCornerShape(12.dp))
                    .border(1.dp, Gold.copy(alpha = 0.20f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(stringResource(R.string.spirit_message), color = Gold.copy(alpha = 0.72f), style = MaterialTheme.typography.labelSmall, letterSpacing = 1.1.sp)
                Text(
                    message.uppercase().take(80),
                    color = BrightGold,
                    fontFamily = FontFamily.Serif,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.goodbye), color = Muted, fontFamily = FontFamily.Serif)
            Spacer(Modifier.height(6.dp))
            Text(
                if (currentSymbol.isBlank()) stringResource(R.string.ritual_mark) else stringResource(R.string.planchette_listening),
                color = Gold.copy(alpha = 0.56f),
                style = MaterialTheme.typography.labelSmall,
                letterSpacing = 1.1.sp
            )
            Text(
                stringResource(R.string.board_hint),
                color = Muted.copy(alpha = 0.72f),
                style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.Center
            )
        }

        Box(
            modifier = Modifier
                .width(92.dp)
                .height(62.dp)
                .scale(planchetteScale)
                .offset {
                    val maxX = (boardWidth - planchetteWidthPx).coerceAtLeast(0)
                    val maxY = (boardHeight - planchetteHeightPx).coerceAtLeast(0)
                    IntOffset(
                        x = (animatedX * maxX).roundToInt().coerceIn(0, maxX),
                        y = (animatedY * maxY).roundToInt().coerceIn(0, maxY)
                    )
                }
                .background(
                    Brush.radialGradient(
                        listOf(
                            if (currentSymbol.isBlank()) BrightGold.copy(alpha = 0.10f) else VeilVioletBright.copy(alpha = 0.34f),
                            Gold.copy(alpha = 0.08f)
                        )
                    ),
                    RoundedCornerShape(topStart = 46.dp, topEnd = 46.dp, bottomStart = 18.dp, bottomEnd = 18.dp)
                )
                .border(
                    if (currentSymbol.isBlank()) 1.dp else 2.dp,
                    if (currentSymbol.isBlank()) BrightGold.copy(alpha = 0.55f) else VeilVioletBright.copy(alpha = 0.92f),
                    RoundedCornerShape(topStart = 46.dp, topEnd = 46.dp, bottomStart = 18.dp, bottomEnd = 18.dp)
                )
                .semantics { contentDescription = planchetteDescription },
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier.width(22.dp).height(22.dp).border(2.dp, Gold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(currentSymbol.take(1), color = PaleGold, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun SecretHostPanel(director: SessionDirector, changed: () -> Unit, closePanel: () -> Unit) {
    var hostText by remember { mutableStateOf("") }
    var hostFact by remember { mutableStateOf("") }
    val directivePolicy = remember { HostDirectivePolicy() }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Wine, Color(0xFF120909))), RoundedCornerShape(16.dp))
            .border(1.dp, Danger.copy(alpha = 0.9f), RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.secret_host), color = Color(0xFFD99696), fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.close), color = Muted, modifier = Modifier.clickable { closePanel() })
        }
        Text(stringResource(R.string.host_access_hint), color = Muted, style = MaterialTheme.typography.bodySmall)
        Text(stringResource(R.string.host_input_guard), color = Color(0xFFB78484), style = MaterialTheme.typography.labelSmall)
        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = hostText,
            onValueChange = { hostText = it.take(120) },
            label = { Text(stringResource(R.string.force_secret_reply)) }
        )
        Button(
            modifier = Modifier.fillMaxWidth(),
            enabled = hostText.isNotBlank() && director.state.phase in setOf(SessionPhase.DIALOGUE, SessionPhase.ESCALATION, SessionPhase.CLIMAX),
            colors = ButtonDefaults.buttonColors(containerColor = Danger),
            onClick = {
                val decision = directivePolicy.validateReply(hostText, System.currentTimeMillis())
                if (decision.accepted) {
                    director.applyHostDirective(UUID.randomUUID().toString(), HostDirective.ForceReply(decision.normalizedText))
                    hostText = ""
                    changed()
                }
            }
        ) { Text(stringResource(R.string.inject_reply)) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                enabled = director.state.phase in setOf(SessionPhase.DIALOGUE, SessionPhase.ESCALATION),
                onClick = { director.applyHostDirective("climax", HostDirective.ForceClimax); changed() }
            ) { Text(stringResource(R.string.climax)) }
        }
        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = hostFact,
            onValueChange = { hostFact = it.take(80) },
            label = { Text(stringResource(R.string.secret_fact_hint)) },
            singleLine = true
        )
        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            enabled = hostFact.isNotBlank(),
            onClick = {
                val decision = directivePolicy.validateFact(hostFact, System.currentTimeMillis())
                if (decision.accepted) {
                    director.applyHostDirective(UUID.randomUUID().toString(), HostDirective.InjectFact("host_fact", decision.normalizedText))
                    hostFact = ""
                    changed()
                }
            }
        ) { Text(stringResource(R.string.save_secret_fact)) }

        HostDiagnostics(director)
    }
}

@Composable
private fun HostDiagnostics(director: SessionDirector) {
    val memory = director.state.memory
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF100A0A), RoundedCornerShape(10.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(stringResource(R.string.host_diagnostics), color = Color(0xFFD99696), fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.memory_stats, memory.turnCount, memory.facts.size, memory.cues.count { !it.used }, memory.qualityInterventions), color = Muted)
        memory.facts.values.take(4).forEach { Text("• ${it.value}", color = PaleGold, style = MaterialTheme.typography.bodySmall) }
        memory.transcript.takeLast(5).forEach { item ->
            Text("${stringResource(roleLabelRes(item.role))}: ${stringResource(sourceLabelRes(item.source))}", color = Muted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun TranscriptPanel(director: SessionDirector, historyLimit: Int) {
    val transcript = director.state.memory.transcript
        .filter { it.role != Role.SYSTEM }
        .takeLast(historyLimit)
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(stringResource(R.string.transcript), color = Gold, fontWeight = FontWeight.Bold)
        if (transcript.isEmpty()) Text(stringResource(R.string.no_events), color = Muted)
        transcript.forEach { item ->
            val prefix = when (item.role) {
                Role.PARTICIPANT -> stringResource(R.string.you)
                Role.SPIRIT -> stringResource(R.string.spirit)
                Role.SYSTEM -> "•"
            }
            Text("$prefix: ${item.text}", color = if (item.role == Role.SPIRIT) PaleGold else Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun roleLabelRes(role: Role) = when (role) {
    Role.PARTICIPANT -> R.string.role_participant
    Role.SPIRIT -> R.string.role_spirit
    Role.SYSTEM -> R.string.role_system
}

private fun sourceLabelRes(source: Source) = when (source) {
    Source.USER -> R.string.source_user
    Source.AI -> R.string.source_ai
    Source.LOCAL_FALLBACK -> R.string.source_local_fallback
    Source.HOST_OVERRIDE -> R.string.source_host_override
    Source.MEMORY_CALLBACK -> R.string.source_memory_callback
}

private fun newDirector() = SessionDirector(SpiritProfile("mara", "Mara", Temperament.GUARDED))

private fun primaryLabelRes(phase: SessionPhase) = when (phase) {
    SessionPhase.IDLE -> R.string.begin_seance
    SessionPhase.INVOCATION -> R.string.establish_contact
    SessionPhase.CONTACT -> R.string.ask_questions
    else -> R.string.continue_label
}

private fun phaseLabelRes(phase: SessionPhase) = when (phase) {
    SessionPhase.IDLE -> R.string.phase_name_idle
    SessionPhase.INVOCATION -> R.string.phase_name_invocation
    SessionPhase.CONTACT -> R.string.phase_name_contact
    SessionPhase.DIALOGUE -> R.string.phase_name_dialogue
    SessionPhase.ESCALATION -> R.string.phase_name_escalation
    SessionPhase.CLIMAX -> R.string.phase_name_climax
    SessionPhase.CLOSING -> R.string.phase_name_closing
    SessionPhase.ENDED -> R.string.phase_name_ended
}

private fun phasePromptRes(phase: SessionPhase) = when (phase) {
    SessionPhase.IDLE -> R.string.phase_idle
    SessionPhase.INVOCATION -> R.string.phase_invocation
    SessionPhase.CONTACT -> R.string.phase_contact
    SessionPhase.DIALOGUE -> R.string.phase_dialogue
    SessionPhase.ESCALATION -> R.string.phase_escalation
    SessionPhase.CLIMAX -> R.string.phase_climax
    SessionPhase.CLOSING -> R.string.phase_closing
    SessionPhase.ENDED -> R.string.phase_ended
}
